# 🧠 PROMPT INTERNO DE MANTENIMIENTO: PANEL DE INERCIA

Este documento sirve como **handoff técnico** para cualquier agente de Inteligencia Artificial que deba mantener, optimizar o extender esta plataforma STEM sobre **Momentos de Inercia en Coronas Circulares**.

---

## 🎯 Contexto del Proyecto
La aplicación es una herramienta interactiva universitaria de ingeniería industrial que conecta la geometría analítica plana con el diseño estructural y de disipación térmica de volantes de inercia y engranajes.

---

## 🏗️ Directrices de Arquitectura

Al modificar este código, debes respetar estrictamente la estructura de 5 capas:

```
┌────────────────────────────────────────────────────────┐
│ Capa 1: Navegador cliente                              │
├────────────────────────────────────────────────────────┤
│ Capa 2: Presentación (index.html + style.css)           │
├────────────────────────────────────────────────────────┤
│ Capa 3: Controlador de eventos y Canvas (app.js)       │
├────────────────────────────────────────────────────────┤
│ Capa 4: Core matemático puro (core/inercia.js)         │
├────────────────────────────────────────────────────────┤
│ Capa 5: Empaquetador Google Sites (build_embed.py)     │
└────────────────────────────────────────────────────────┘
```

### Reglas Inquebrantables de Codificación:
1.  **Cero Cálculos Matemáticos en app.js**: Toda física o geometría se calcula llamando a las funciones puras en [inercia.js](file:///c:/Users/luisa/Desktop/INERCIA/core/inercia.js). No uses `Math.PI` o `Math.cos` directamente en la UI.
2.  **Inmunidad a Errores (Fail-Safe)**: Si extiendes las funciones del core, asegúrate de que cualquier valor inválido o corrupto (`NaN`, `null`, strings incorrectos) retorne un fallback seguro (`0`, `false`).
3.  **Mantén la Cobertura de Pruebas**: Cualquier nueva función añadida al core debe poseer sus correspondientes pruebas unitarias en [inercia.test.js](file:///c:/Users/luisa/Desktop/INERCIA/tests/inercia.test.js) contemplando casos nominales, fronteras, inválidos y corruptos.
4.  **No Emojis en Scripts de Consola**: Evita incluir caracteres Unicode/Emojis en los mensajes de consola impresos por scripts ejecutados en Windows, para prevenir fallas de codificación en terminales PowerShell.
5.  **Preserva la Accesibilidad WCAG 2.1 AA**:
    *   No añadas elementos interactivos sin el atributo `tabindex` y roles ARIA apropiados.
    *   Mantén las etiquetas descriptivas dinámicas `aria-label` en los lienzos `<canvas>`.
    *   No elimines los estilos de visibilidad de foco ni las reglas de reducción de animaciones (`prefers-reduced-motion`).

---

## 🚀 Flujo de Trabajo para Nuevas Funciones

Si deseas agregar un nuevo parámetro (por ejemplo, permitir acoplamientos triangulares o análisis de esfuerzos centrífugos avanzados):

1.  **Paso 1: Modifica el Core**: Añade la función matemática en `core/inercia.js`.
2.  **Paso 2: Escribe Pruebas**: Añade el bloque `describe` con los 4 casos de prueba en `tests/inercia.test.js`.
3.  **Paso 3: Corre los Tests**: Ejecuta `node tests/inercia.test.js` en tu terminal. Todos deben pasar en verde.
4.  **Paso 4: Actualiza la UI**: Liga la nueva función a los elementos gráficos y sliders en `app.js` e `index.html`.
5.  **Paso 5: Compila**: Ejecuta `python build_embed.py` para generar la compilación embebida y verifica que el tamaño final no supere los 500 KB.
6.  **Paso 6: Actualiza el Inventario**: Documenta el cambio en [TECHNICAL-INVENTORY.md](file:///c:/Users/luisa/Desktop/INERCIA/TECHNICAL-INVENTORY.md) y [SPEC-VS-IMPL.md](file:///c:/Users/luisa/Desktop/INERCIA/SPEC-VS-IMPL.md).
