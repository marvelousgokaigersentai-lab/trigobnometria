/*=============================================================================
  core/inercia.js
  NÚCLEO MATEMÁTICO AISLADO — FUNCIONES PURAS
  SIN DEPENDENCIAS DE DOM, CANVAS O LIBRERÍAS DE INTERFAZ
=============================================================================*/

/**
 * Valida si un valor es número finito
 * @param {*} x - Valor a validar
 * @returns {boolean}
 */
export function isValidNumber(x) {
  return typeof x === 'number' && Number.isFinite(x);
}

/**
 * Convierte a número finito con fallback
 * @param {*} x - Valor a convertir
 * @param {number} fallback - Valor por defecto (default: 0)
 * @returns {number}
 */
export function toFiniteNumber(x, fallback = 0) {
  if (x === null || x === undefined || typeof x === 'boolean') return fallback;
  const n = Number(x);
  return Number.isFinite(n) ? n : fallback;
}

/**
 * Calcula el área de una corona circular
 * A = pi * (R^2 - r^2)
 * @param {number} R - Radio exterior
 * @param {number} r - Radio interior
 * @returns {number} Área de la corona (0 si es inválido)
 */
export function calcularArea(R, r) {
  if (!isValidNumber(R) || !isValidNumber(r)) return 0;
  
  const R_val = toFiniteNumber(R);
  const r_val = toFiniteNumber(r);
  
  if (R_val <= 0 || r_val < 0 || R_val < r_val) return 0;
  return Math.PI * (R_val * R_val - r_val * r_val);
}

/**
 * Calcula el momento polar de inercia J de una corona circular
 * J = (pi / 2) * (R^4 - r^4)
 * @param {number} R - Radio exterior
 * @param {number} r - Radio interior
 * @returns {number} Momento polar de inercia (0 si es inválido)
 */
export function calcularMomentoPolarJ(R, r) {
  if (!isValidNumber(R) || !isValidNumber(r)) return 0;
  
  const R_val = toFiniteNumber(R);
  const r_val = toFiniteNumber(r);
  
  if (R_val <= 0 || r_val < 0 || R_val < r_val) return 0;
  return (Math.PI / 2) * (Math.pow(R_val, 4) - Math.pow(r_val, 4));
}

/**
 * Calcula el apotema de un polígono regular de N lados inscrito en un círculo de radio R
 * a = R * cos(pi / lados)
 * @param {number} R - Radio exterior
 * @param {number} lados - Número de lados del polígono regular (ej. cuadrado = 4, hexágono = 6)
 * @returns {number} Apotema (0 si es inválido)
 */
export function calcularApotema(R, lados = 4) {
  if (!isValidNumber(R) || !isValidNumber(lados)) return 0;
  
  const R_val = toFiniteNumber(R);
  const lados_val = toFiniteNumber(lados, 4);
  
  if (R_val <= 0 || lados_val < 3) return 0;
  return R_val * Math.cos(Math.PI / lados_val);
}

/**
 * Determina si la corona circular es estructuralmente segura
 * Es segura si el radio interior r es menor o igual al apotema del acople (r <= a)
 * @param {number} R - Radio exterior
 * @param {number} r - Radio interior
 * @param {number} lados - Número de lados del acople (default: 4 para cuadrado)
 * @returns {boolean} True si es segura, false de lo contrario o ante parámetros inválidos
 */
export function esEstructuraSegura(R, r, lados = 4) {
  if (!isValidNumber(R) || !isValidNumber(r) || !isValidNumber(lados)) return false;
  
  const R_val = toFiniteNumber(R);
  const r_val = toFiniteNumber(r);
  const lados_val = toFiniteNumber(lados, 4);
  
  if (R_val <= 0 || r_val < 0 || R_val < r_val) return false;
  
  const apotema = calcularApotema(R_val, lados_val);
  return r_val <= apotema;
}

/**
 * Calcula el perímetro total de la corona (borde exterior + borde interior)
 * P = 2 * pi * (R + r)
 * @param {number} R - Radio exterior
 * @param {number} r - Radio interior
 * @returns {number} Perímetro total para disipación térmica (0 si es inválido)
 */
export function calcularPerimetroTotal(R, r) {
  if (!isValidNumber(R) || !isValidNumber(r)) return 0;
  
  const R_val = toFiniteNumber(R);
  const r_val = toFiniteNumber(r);
  
  if (R_val <= 0 || r_val < 0 || R_val < r_val) return 0;
  return 2 * Math.PI * (R_val + r_val);
}

/**
 * Calcula la eficiencia de material (J / A)
 * J / A = (R^2 + r^2) / 2
 * @param {number} R - Radio exterior
 * @param {number} r - Radio interior
 * @returns {number} Eficiencia del material en cm^2 (0 si es inválido)
 */
export function calcularEficienciaJ(R, r) {
  if (!isValidNumber(R) || !isValidNumber(r)) return 0;
  
  const R_val = toFiniteNumber(R);
  const r_val = toFiniteNumber(r);
  
  if (R_val <= 0 || r_val < 0 || R_val < r_val) return 0;
  return (R_val * R_val + r_val * r_val) / 2;
}

/**
 * Calcula el porcentaje de masa/material que se ahorra comparado con un disco sólido
 * Ahorro = r^2 / R^2 * 100%
 * @param {number} R - Radio exterior
 * @param {number} r - Radio interior
 * @returns {number} Porcentaje de ahorro de masa (0 si es inválido)
 */
export function calcularPorcentajeAhorroMasa(R, r) {
  if (!isValidNumber(R) || !isValidNumber(r)) return 0;
  
  const R_val = toFiniteNumber(R);
  const r_val = toFiniteNumber(r);
  
  if (R_val <= 0 || r_val < 0 || R_val < r_val) return 0;
  return (r_val * r_val) / (R_val * R_val) * 100;
}

/**
 * Calcula el porcentaje de inercia retenida comparada con un disco sólido de radio R
 * Retencion = (1 - r^4 / R^4) * 100%
 * @param {number} R - Radio exterior
 * @param {number} r - Radio interior
 * @returns {number} Porcentaje de inercia retenida (0 si es inválido)
 */
export function calcularPorcentajeRetencionInercia(R, r) {
  if (!isValidNumber(R) || !isValidNumber(r)) return 0;
  
  const R_val = toFiniteNumber(R);
  const r_val = toFiniteNumber(r);
  
  if (R_val <= 0 || r_val < 0 || R_val < r_val) return 0;
  return (1 - Math.pow(r_val, 4) / Math.pow(R_val, 4)) * 100;
}
