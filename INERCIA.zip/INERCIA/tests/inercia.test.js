/*=============================================================================
  tests/inercia.test.js
  SCRIPT DE PRUEBAS UNITARIAS EN JAVASCRIPT PURO
  SE EJECUTA CON: node tests/inercia.test.js
=============================================================================*/

import {
  isValidNumber,
  toFiniteNumber,
  calcularArea,
  calcularMomentoPolarJ,
  calcularApotema,
  esEstructuraSegura,
  calcularPerimetroTotal,
  calcularEficienciaJ,
  calcularPorcentajeAhorroMasa,
  calcularPorcentajeRetencionInercia
} from '../core/inercia.js';

let totalTests = 0;
let passedTests = 0;

function describe(label, fn) {
  console.log(`\n📋 ${label}`);
  fn();
}

function it(label, fn) {
  totalTests++;
  try {
    fn();
    passedTests++;
    console.log(`  ✅ ${label}`);
  } catch (error) {
    console.error(`  ❌ ${label}`);
    console.error(`     Error: ${error.message}`);
  }
}

function assertEqual(actual, expected, message) {
  if (Math.abs(actual - expected) > 1e-6) {
    throw new Error(`${message || 'No son iguales'}: esperado ${expected}, obtenido ${actual}`);
  }
}

function assertStrictEqual(actual, expected, message) {
  if (actual !== expected) {
    throw new Error(`${message || 'No son estrictamente iguales'}: esperado ${expected}, obtenido ${actual}`);
  }
}

//=== INICIO DE PRUEBAS ===

describe('isValidNumber', () => {
  it('debe retornar true para números finitos', () => {
    assertStrictEqual(isValidNumber(10), true);
    assertStrictEqual(isValidNumber(-1.5), true);
    assertStrictEqual(isValidNumber(0), true);
  });

  it('debe retornar false para NaN, Infinity y tipos no numéricos', () => {
    assertStrictEqual(isValidNumber(NaN), false);
    assertStrictEqual(isValidNumber(Infinity), false);
    assertStrictEqual(isValidNumber("10"), false);
    assertStrictEqual(isValidNumber(null), false);
    assertStrictEqual(isValidNumber(undefined), false);
  });
});

describe('toFiniteNumber', () => {
  it('debe retornar el número si es válido', () => {
    assertStrictEqual(toFiniteNumber(5), 5);
    assertStrictEqual(toFiniteNumber(-12.5), -12.5);
  });

  it('debe convertir strings numéricos si es posible', () => {
    assertStrictEqual(toFiniteNumber("123"), 123);
  });

  it('debe usar fallback si no es convertible o es inválido', () => {
    assertStrictEqual(toFiniteNumber(NaN, 10), 10);
    assertStrictEqual(toFiniteNumber("texto", 5), 5);
    assertStrictEqual(toFiniteNumber(null, 2), 2);
  });
});

describe('calcularArea', () => {
  it('caso nominal: corona válida', () => {
    // R = 10, r = 5. A = pi * (100 - 25) = 75 * pi ≈ 235.619449
    assertEqual(calcularArea(10, 5), Math.PI * 75);
  });

  it('caso límite: r = 0 (disco sólido)', () => {
    assertEqual(calcularArea(10, 0), Math.PI * 100);
  });

  it('caso límite: R = r (espesor cero)', () => {
    assertEqual(calcularArea(10, 10), 0);
  });

  it('caso inválido: R < r', () => {
    assertStrictEqual(calcularArea(5, 10), 0);
  });

  it('caso corrupto: NaN, negativos o nulos', () => {
    assertStrictEqual(calcularArea(-10, 5), 0);
    assertStrictEqual(calcularArea(10, -5), 0);
    assertStrictEqual(calcularArea(NaN, 5), 0);
    assertStrictEqual(calcularArea(10, "invalido"), 0);
  });
});

describe('calcularMomentoPolarJ', () => {
  it('caso nominal: corona válida', () => {
    // R = 10, r = 5. J = (pi/2) * (10^4 - 5^4) = (pi/2) * (10000 - 625) = (pi/2) * 9375 ≈ 14726.21556
    assertEqual(calcularMomentoPolarJ(10, 5), (Math.PI / 2) * 9375);
  });

  it('caso límite: r = 0 (disco sólido)', () => {
    assertEqual(calcularMomentoPolarJ(10, 0), (Math.PI / 2) * 10000);
  });

  it('caso inválido y corrupto', () => {
    assertStrictEqual(calcularMomentoPolarJ(5, 10), 0);
    assertStrictEqual(calcularMomentoPolarJ(-10, 5), 0);
    assertStrictEqual(calcularMomentoPolarJ(10, NaN), 0);
  });
});

describe('calcularApotema', () => {
  it('caso nominal: cuadrado (lados = 4) inscrito en R = 10', () => {
    // a = 10 * cos(pi/4) = 10 * cos(45°) = 10 * sqrt(2)/2 ≈ 7.071068
    assertEqual(calcularApotema(10, 4), 10 * Math.sqrt(2) / 2);
  });

  it('caso nominal: hexágono (lados = 6) inscrito en R = 10', () => {
    // a = 10 * cos(pi/6) = 10 * cos(30°) = 10 * sqrt(3)/2 ≈ 8.660254
    assertEqual(calcularApotema(10, 6), 10 * Math.sqrt(3) / 2);
  });

  it('caso inválido', () => {
    assertStrictEqual(calcularApotema(10, 2), 0); // Polígono imposible
    assertStrictEqual(calcularApotema(-5, 4), 0);
  });
});

describe('esEstructuraSegura', () => {
  it('caso seguro: r <= apotema', () => {
    // R = 10, lados = 4 => a ≈ 7.071. Si r = 6 => seguro (true)
    assertStrictEqual(esEstructuraSegura(10, 6, 4), true);
    // r = 7.07 => seguro (true)
    assertStrictEqual(esEstructuraSegura(10, 7.07, 4), true);
  });

  it('caso inseguro (falla estructural): r > apotema', () => {
    // R = 10, lados = 4 => a ≈ 7.071. Si r = 8 => inseguro (false)
    assertStrictEqual(esEstructuraSegura(10, 8, 4), false);
  });

  it('caso corrupto', () => {
    assertStrictEqual(esEstructuraSegura(-10, 5, 4), false);
    assertStrictEqual(esEstructuraSegura(10, NaN, 4), false);
  });
});

describe('calcularPerimetroTotal', () => {
  it('caso nominal', () => {
    // R = 10, r = 5 => P = 2 * pi * 15 = 30 * pi ≈ 94.247779
    assertEqual(calcularPerimetroTotal(10, 5), 2 * Math.PI * 15);
  });
});

describe('calcularEficienciaJ', () => {
  it('caso nominal', () => {
    // R = 10, r = 5 => Eficiencia = (100 + 25) / 2 = 62.5
    assertEqual(calcularEficienciaJ(10, 5), 62.5);
  });
});

describe('calcularPorcentajeAhorroMasa', () => {
  it('caso nominal', () => {
    // R = 10, r = 5 => ahorro = 25 / 100 * 100% = 25%
    assertEqual(calcularPorcentajeAhorroMasa(10, 5), 25.0);
  });
});

describe('calcularPorcentajeRetencionInercia', () => {
  it('caso nominal', () => {
    // R = 10, r = 5 => retencion = (1 - 625/10000) * 100% = (1 - 0.0625) * 100% = 93.75%
    assertEqual(calcularPorcentajeRetencionInercia(10, 5), 93.75);
  });
});

//=== RESUMEN ===
console.log(`\n===================================`);
console.log(`📊 Pruebas totales: ${totalTests}`);
console.log(`🟢 Pruebas exitosas: ${passedTests}`);
console.log(`🔴 Pruebas fallidas: ${totalTests - passedTests}`);
console.log(`===================================`);

if (passedTests === totalTests) {
  console.log("🚀 ¡Todos los tests del núcleo matemático pasaron con éxito!\n");
  process.exit(0);
} else {
  console.error("❌ Se encontraron fallas en las pruebas unitarias.\n");
  process.exit(1);
}
