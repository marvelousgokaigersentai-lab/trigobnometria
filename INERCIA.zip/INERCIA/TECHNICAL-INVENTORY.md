# 🛠️ TECHNICAL-INVENTORY — Panel Web de Momentos de Inercia

## 1. Arquitectura del Sistema
El sistema está desarrollado bajo una arquitectura desacoplada de 5 capas:

1.  **Capa 1 (Presentación/Cliente)**: Navegador web estándar. Compatible con Chrome, Firefox, Safari y Edge.
2.  **Capa 2 (Estructura e Interfaz)**: `index.html` y `style.css`. Proveen la maqueta accesible WCAG 2.1 AA y el diseño visual Space Dark / Glassmorphism.
3.  **Capa 3 (Lógica de Interfaz)**: `app.js`. Controla los eventos DOM, sincroniza los sliders de laboratorio, administra la base de datos de ejercicios interactivos y propuestos, y coordina las animaciones del lienzo Canvas 2D.
4.  **Capa 4 (Núcleo de Cálculo)**: `core/inercia.js`. Contiene funciones puras matemáticas de cálculo geométrico y de inercia, totalmente libres de referencias al DOM, Canvas o MathJax.
5.  **Capa 5 (Infraestructura de Distribución)**: `build_embed.py`. Script en Python que compila todo el sistema en un solo archivo inyectable (`google_sites_embed.html`), ideal para ser embebido en Google Sites sin dependencias de red o archivos adjuntos.

---

## 2. API del Núcleo Matemático (`core/inercia.js`)

El archivo expone las siguientes funciones puras documentadas:

*   `isValidNumber(x)`: Valida si una variable es numérica y finita.
*   `toFiniteNumber(x, fallback)`: Convierte un valor a numérico seguro con fallback ante valores no convertibles.
*   `calcularArea(R, r)`: Retorna el área transversal sólida de la corona circular: \(\pi(R^2 - r^2)\). Retorna `0` ante entradas no válidas o si \(R < r\).
*   `calcularMomentoPolarJ(R, r)`: Retorna el momento polar de inercia de cuarto orden: \(\frac{\pi}{2}(R^4 - r^4)\). Retorna `0` ante entradas no válidas o si \(R < r\).
*   `calcularApotema(R, lados)`: Retorna la apotema de un polígono regular inscrito en un círculo de radio exterior \(R\): \(R \cos(\frac{\pi}{\text{lados}})\).
*   `esEstructuraSegura(R, r, lados)`: Retorna un booleano que define si la corona es segura (el radio interior \(r\) no corta las caras del acoplamiento central poligonal, es decir: \(r \le a\)).
*   `calcularPerimetroTotal(R, r)`: Retorna la suma de perímetros para análisis de transferencia de calor: \(2\pi(R + r)\).
*   `calcularEficienciaJ(R, r)`: Retorna la eficiencia del material (inercia por unidad de área): \(\frac{R^2 + r^2}{2}\).
*   `calcularPorcentajeAhorroMasa(R, r)`: Retorna el porcentaje de masa removida respecto a un disco sólido de radio \(R\).
*   `calcularPorcentajeRetencionInercia(R, r)`: Retorna la inercia conservada respecto a un disco sólido de radio \(R\).

---

## 3. Dependencias de Terceros (CDNs)
Para asegurar el funcionamiento autocontenido, el panel utiliza exclusivamente las siguientes librerías desde CDN:
*   **FontAwesome (v6.4.0)**: Carga de íconos estilizados para interfaz e indicadores.
    *   URL: `https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css`
*   **MathJax (v3)**: Renderizador de ecuaciones matemáticas complejas escritas en LaTeX.
    *   URL: `https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js`

---

## 4. Pruebas Unitarias
El núcleo matemático se valida de forma automatizada mediante el script `tests/inercia.test.js`.
*   **Cobertura**: 100% de las funciones matemáticas críticas cubiertas.
*   **Casos probados por función**:
    1.  *Caso nominal*: Valores comunes de ingeniería.
    2.  *Caso límite*: Fronteras (radio interior cero, espesor cero).
    3.  *Caso inválido*: Radios invertidos o valores negativos.
    4.  *Caso corrupto*: Valores `NaN`, `null`, `undefined` o tipos incorrectos, validando la inmunidad a errores.

---

## 5. Deuda Técnica y Mitigación
*   **MathJax en Acordeones**: El rediseño dinámico de MathJax dentro de los acordeones de ejercicios propuestos puede provocar pequeños retardos visuales en dispositivos móviles lentos al renderizar SVG.
    *   *Mitigación*: Se utiliza `MathJax.typesetPromise` de manera selectiva pasando el elemento del cuerpo del acordeón específico en lugar de re-renderizar todo el documento.
*   **Consumo de CPU por requestAnimationFrame**: El bucle del lienzo interactivo de la pestaña de laboratorio consume CPU continuamente cuando el volante está girando.
    *   *Mitigación*: El bucle de animación se cancela inmediatamente mediante `cancelAnimationFrame` cuando el usuario se cambia de pestaña o cuando la velocidad de rotación es cero (\(\omega = 0\)).

---

## 6. Roadmap y Evolución Futura
1.  **Modelo de Elementos Finitos (FEM 1D)**: Implementar una aproximación numérica del gradiente de tensiones centrífugas a lo largo del radio para mostrar visualmente las zonas de alta concentración de esfuerzos en la corona.
2.  **Soporte de Chaveteros estándar (DIN 6885)**: Incluir acoplamientos de chaveta además de polígonos regulares para modelar chaveteros industriales típicos.
3.  **Base de Datos persistente**: Implementar almacenamiento local (`localStorage`) para registrar qué ejercicios ha resuelto el estudiante en su sesión de estudio.
