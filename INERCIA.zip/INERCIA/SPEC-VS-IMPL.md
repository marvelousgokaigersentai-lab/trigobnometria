# 📋 SPEC-VS-IMPL — Comparativa de Especificación vs Implementación

Este documento detalla el cumplimiento de los requerimientos teóricos (documento Word) y técnicos (documento Markdown) establecidos para el desarrollo del panel web interactivo de Momentos de Inercia.

---

## 1. Mapeo de Requerimientos del Documento Word

| Requerimiento Teórico (Word) | Estado | Implementación en el Panel Web |
| :--- | :--- | :--- |
| **Definición de Corona Circular**: Ecuación de Área \(A = \pi(R^2 - r^2)\). | ✅ Implementado | Pestaña 1 (Lab) calcula el área dinámicamente; Pestaña 3 (Propiedades) explica su física; E1 y E13 abordan este cálculo directamente. |
| **Definición de Inercia Polar**: Resistencia a la rotación \(J = \frac{\pi}{2}(R^4 - r^4)\). | ✅ Implementado | Calculado en tiempo real en la Pestaña 1; Pestaña 3 explica el concepto; E2 y E14 abordan este cálculo. |
| **Factorización y Relación J/A**: Reducción de fórmula a \(J = \frac{A}{2}(R^2 + r^2)\). | ✅ Implementado | Pestaña 3 (Propiedades) desglosa el álgebra completa. El Lab muestra la eficiencia de material \(J/A\) en cm². |
| **Apotema y Falla Estructural**: Límite de radio interior respecto a la apotema del cuadrado (\(r \le R \cos 45^\circ\)). | ✅ Implementado | Pestaña 1 muestra un badge dinámico ("Estructura Segura" vs "Falla Estructural") y sombrea en rojo en el canvas las áreas de colisión de material. |
| **Relación Óptima de Diseño**: Relación óptima en el límite \(r/R = 0.707\). | ✅ Implementado | Pestaña 2 (Clasificación) ofrece un preajuste rápido para "Corona Óptima". Pestaña 3 deduce matemáticamente el óptimo. |
| **Área Simétrica (División al 50%)**: El área de la corona óptima es la mitad del círculo sólido. | ✅ Implementado | Demostrado matemáticamente en la pestaña 3. E11 y E24 guían al alumno en esta demostración analítica. |
| **Disipación Térmica (Perímetro)**: Perímetro de enfriamiento \(P = 2\pi(R + r)\). | ✅ Implementado | Explicado en la pestaña 3 y calculado en los ejercicios interactivos (E4) y propuestos (E19). |

---

## 2. Mapeo de Parámetros Técnicos (AGENT-PROMPT-v2.md)

| Parámetro Técnico | Estado | Implementación |
| :--- | :--- | :--- |
| **Arquitectura de 5 Capas** | ✅ Cumplido | Código estructurado en HTML (capa 2), CSS (capa 2), lógica en `app.js` (capa 3), matemáticas en `core/inercia.js` (capa 4), y compilador en Python (capa 5). |
| **Estilo Space Dark & Glassmorphic** | ✅ Cumplido | Uso de fuentes Outfit e Inter, degradado profundo con acentos neón semánticos (Indigo/Púrpura/Verde/Rosa) y tarjetas de cristal con `backdrop-filter: blur(12px)`. |
| **7 Pestañas Pedagógicas (Nivel Bloom)** | ✅ Cumplido | 1. Intro & Lab (Recordar), 2. Clasificación (Comprender), 3. Propiedades (Aplicar), 4. Elementos (Analizar), 5. Ingeniería (Evaluar), 6. 12 Ejs. Interactivos (Crear), 7. 12 Ejs. Propuestos (Crear). |
| **Núcleo Matemático Aislado** | ✅ Cumplido | El archivo `core/inercia.js` no importa DOM ni realiza manipulación gráfica. Es 100% testeable de forma aislada. |
| **Invariantes Fail-Safe** | ✅ Cumplido | Las funciones matemáticas retornan 0 o false ante valores corruptos (`NaN`, `null`, tipos string inválidos). |
| **Pruebas unitarias** | ✅ Cumplido | 23 pruebas unitarias implementadas en `tests/inercia.test.js` y ejecutadas exitosamente sobre el núcleo matemático. |
| **Soporte Hi-DPI en Canvas** | ✅ Cumplido | El helper `getScaledContext` escala los Canvas 2D dinámicamente usando `window.devicePixelRatio` para evitar pixelado en pantallas Retina. |
| **Accesibilidad WCAG 2.1 AA** | ✅ Cumplido | Implementado skip-link, navegación por teclado en la barra de pestañas, etiquetas dinámicas `aria-label` en canvas y contraste de texto superior a 4.5:1. |
| **Compilador para Google Sites** | ✅ Cumplido | Script `build_embed.py` inyecta con éxito el CSS y JS compilado dentro del HTML, generando `google_sites_embed.html` de 119 KB. |

---

## 3. Discrepancias Resueltas durante la Implementación
*   **Gestión de nulos en `toFiniteNumber`**: Inicialmente, la función de conversión pasaba `null` a `Number(null)` resultando en `0` (el cual es finito y pasaba como válido). Se corrigió agregando un filtro estricto al inicio de la función para descartar de forma inequívoca valores `null`, `undefined` y booleanos, forzando el retorno del valor de fallback correspondiente.
*   **Emojis en la consola de comandos de Windows**: Se removieron los emojis decorativos del script de compilación y de pruebas para prevenir excepciones por codificación de caracteres `CP1252` al ejecutar las herramientas mediante PowerShell en sistemas operativos Windows.
