import os
import re

def build():
    cwd = os.path.dirname(os.path.abspath(__file__))
    index_path = os.path.join(cwd, 'index.html')
    style_path = os.path.join(cwd, 'style.css')
    app_path = os.path.join(cwd, 'app.js')
    core_path = os.path.join(cwd, 'core', 'inercia.js')
    output_path = os.path.join(cwd, 'google_sites_embed.html')
    
    print("[INFO] Iniciando compilacion del panel educativo...")
    
    # 1. Leer archivos
    if not os.path.exists(index_path):
        print("[ERROR] index.html no existe.")
        return
    if not os.path.exists(style_path):
        print("[ERROR] style.css no existe.")
        return
    if not os.path.exists(app_path):
        print("[ERROR] app.js no existe.")
        return
    if not os.path.exists(core_path):
        print("[ERROR] core/inercia.js no existe.")
        return

    with open(index_path, 'r', encoding='utf-8') as f:
        html = f.read()
    with open(style_path, 'r', encoding='utf-8') as f:
        css = f.read()
    with open(app_path, 'r', encoding='utf-8') as f:
        app_js = f.read()
    with open(core_path, 'r', encoding='utf-8') as f:
        core_js = f.read()
    
    # 2. Procesar el Nucleo Matematico (core/inercia.js)
    # Remover los prefijos 'export ' de las funciones
    core_js_clean = re.sub(r'\bexport\s+function\s+', 'function ', core_js)
    
    # 3. Procesar la App (app.js)
    # Remover la importacion de core/inercia.js. Puede ser multiline.
    app_js_clean = re.sub(
        r'import\s+\{[^}]*\}\s+from\s+[\'"]\./core/inercia\.js[\'"];?',
        '',
        app_js,
        flags=re.DOTALL
    )
    
    # 4. Combinar archivos JS
    combined_js = f"""/*=== COMPILACION AUTOMATICA DEL SISTEMA ===*/

/*=== 1. NUCLEO MATEMATICO DE INERCIA ===*/
{core_js_clean}

/*=== 2. CONTROLADOR DE INTERFAZ Y CANVAS ===*/
{app_js_clean}"""

    # 5. Reemplazar CSS link por inline en index.html
    # Busca <link rel="stylesheet" href="style.css"> o similar
    html = re.sub(
        r'<link\s+rel="stylesheet"\s+href="style\.css"\s*/?>',
        f'<style>\n{css}\n</style>',
        html
    )
    
    # 6. Reemplazar JS script por inline en index.html
    # Busca <script type="module" src="app.js"></script> o similar
    html = re.sub(
        r'<script\s+type="module"\s+src="app\.js"\s*></script>',
        f'<script>\n{combined_js}\n</script>',
        html
    )
    
    # 7. Guardar el resultado final
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)
    
    # 8. Mostrar estadisticas basicas
    original_size = (os.path.getsize(index_path) + os.path.getsize(style_path) + 
                     os.path.getsize(app_path) + os.path.getsize(core_path)) / 1024
    compiled_size = os.path.getsize(output_path) / 1024
    
    print(f"[SUCCESS] Compilacion exitosa: {output_path}")
    print(f"[INFO] Tamano combinado original: {original_size:.2f} KB")
    print(f"[INFO] Tamano compilado inline: {compiled_size:.2f} KB")

if __name__ == '__main__':
    build()
