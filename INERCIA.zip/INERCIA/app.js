/*=============================================================================
  app.js
  CONTROLADOR PRINCIPAL DE LA INTERFAZ DE USUARIO (UI)
  DISEÑO SPACE DARK + GLASSMORPHISM + ACCESIBILIDAD WCAG AA
=============================================================================*/

import {
  calcularArea,
  calcularMomentoPolarJ,
  calcularApotema,
  esEstructuraSegura,
  calcularPerimetroTotal,
  calcularEficienciaJ,
  calcularPorcentajeAhorroMasa,
  calcularPorcentajeRetencionInercia
} from './core/inercia.js';

/*=== REGISTRO GLOBAL DE CANVAS ===*/
window.canvasDrawers = {};
let activeTabId = 'lab';
let rotationAngle = 0;
let animationFrameIds = {};

/*=== INICIALIZACIÓN GENERAL ===*/
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initLab();
  initClassification();
  initAnatomy();
  initExercises();
  initProposedExercises();
  
  // Renderizado inicial
  triggerTabDraw(activeTabId);
});

/*=== 1. SISTEMA DE PESTAÑAS (TABS) ACCESIBLES ===*/
function initTabs() {
  const tablist = document.querySelector('.tabs-navigation');
  const tabs = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.tab-panel');

  function activateTab(targetTab) {
    const targetPanelId = targetTab.getAttribute('aria-controls');
    
    // Detener todas las animaciones en curso
    stopAllAnimations();

    tabs.forEach(tab => {
      const selected = tab === targetTab;
      tab.setAttribute('aria-selected', selected ? 'true' : 'false');
      tab.setAttribute('tabindex', selected ? '0' : '-1');
    });

    panels.forEach(panel => {
      if (panel.id === targetPanelId) {
        panel.classList.add('active');
      } else {
        panel.classList.remove('active');
      }
    });

    activeTabId = targetPanelId.replace('tab-', '');
    
    // Disparar dibujo de la pestaña activa
    triggerTabDraw(activeTabId);

    // Re-renderizar fórmulas de MathJax en el panel activo
    const activePanel = document.getElementById(targetPanelId);
    if (window.MathJax && activePanel) {
      MathJax.typesetPromise([activePanel]).catch(err => console.log('MathJax error:', err));
    }
  }

  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => activateTab(tab));
    
    // Navegación por teclado (Flechas de dirección)
    tab.addEventListener('keydown', (e) => {
      let newIndex = index;
      if (e.key === 'ArrowRight') {
        newIndex = (index + 1) % tabs.length;
      } else if (e.key === 'ArrowLeft') {
        newIndex = (index - 1 + tabs.length) % tabs.length;
      } else if (e.key === 'Home') {
        newIndex = 0;
      } else if (e.key === 'End') {
        newIndex = tabs.length - 1;
      } else {
        return;
      }
      e.preventDefault();
      tabs[newIndex].focus();
      activateTab(tabs[newIndex]);
    });
  });
}

function triggerTabDraw(tabName) {
  if (window.canvasDrawers && window.canvasDrawers[tabName]) {
    // Retardo sutil para asegurar el layout correcto del DOM y dimensiones del Canvas
    setTimeout(() => {
      window.canvasDrawers[tabName]();
    }, 80);
  }
}

function stopAllAnimations() {
  Object.keys(animationFrameIds).forEach(id => {
    cancelAnimationFrame(animationFrameIds[id]);
  });
  animationFrameIds = {};
}

/*=== SOPORTE HI-DPI PARA CANVAS ===*/
function getScaledContext(canvas) {
  const rect = canvas.getBoundingClientRect();
  const displayWidth = rect.width || parseInt(canvas.getAttribute('width')) || 500;
  const displayHeight = rect.height || parseInt(canvas.getAttribute('height')) || 400;
  const dpr = window.devicePixelRatio || 1;
  
  if (canvas.width !== Math.floor(displayWidth * dpr) || 
      canvas.height !== Math.floor(displayHeight * dpr)) {
    canvas.width = displayWidth * dpr;
    canvas.height = displayHeight * dpr;
    canvas.style.width = `${displayWidth}px`;
    canvas.style.height = `${displayHeight}px`;
  }
  
  const ctx = canvas.getContext('2d');
  ctx.resetTransform();
  ctx.scale(dpr, dpr);
  return ctx;
}

/* Rejilla de Fondo Técnica */
function drawGrid(ctx, w, h, size = 30) {
  ctx.strokeStyle = '#0f172a';
  ctx.lineWidth = 1;
  for (let x = 0; x < w; x += size) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y < h; y += size) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }
}

/*=== 2. CONTROLADOR: INTRO & LAB (PESTAÑA 1) ===*/
let labR = 10;
let labr = 5;
let labLados = 4;
let labOmega = 10;

function initLab() {
  const inputR = document.getElementById('input-R');
  const inputr = document.getElementById('input-r');
  const selectLados = document.getElementById('select-lados');
  const inputOmega = document.getElementById('input-omega');
  
  const labelR = document.getElementById('label-R');
  const labelr = document.getElementById('label-r');
  const labelOmega = document.getElementById('label-omega');
  
  // Sincronizar Sliders
  function updateValues() {
    labR = parseFloat(inputR.value);
    labr = parseFloat(inputr.value);
    
    // Evitar que el radio interior sea mayor que el exterior
    if (labr >= labR) {
      labr = labR - 0.5;
      inputr.value = labr;
    }
    
    // Clampear dinámicamente el valor máximo del slider interior
    inputr.max = (labR - 0.5).toFixed(1);
    
    labLados = parseInt(selectLados.value);
    labOmega = parseFloat(inputOmega.value);
    
    labelR.textContent = `${labR.toFixed(1)} cm`;
    labelr.textContent = `${labr.toFixed(1)} cm`;
    labelOmega.textContent = `${labOmega.toFixed(0)} rad/s`;
    
    // Realizar Cálculos
    const area = calcularArea(labR, labr);
    const inercia = calcularMomentoPolarJ(labR, labr);
    const ahorroMasa = calcularPorcentajeAhorroMasa(labR, labr);
    const retencionInercia = calcularPorcentajeRetencionInercia(labR, labr);
    const apotema = calcularApotema(labR, labLados);
    const esSeguro = esEstructuraSegura(labR, labr, labLados);
    
    // Actualizar Textos
    document.getElementById('metric-area').textContent = `${area.toFixed(1)} cm²`;
    document.getElementById('metric-inertia').textContent = `${inercia.toFixed(0)} cm⁴`;
    document.getElementById('metric-mass-saving').textContent = `${ahorroMasa.toFixed(1)}%`;
    document.getElementById('metric-inertia-retention').textContent = `${retencionInercia.toFixed(1)}%`;
    document.getElementById('metric-apothem').textContent = `${apotema.toFixed(2)} cm`;
    
    // Badge de Seguridad
    const badge = document.getElementById('status-badge');
    if (esSeguro) {
      badge.className = 'status-badge safe';
      badge.innerHTML = '<i class="fa-solid fa-circle-check"></i> Estructura Segura';
    } else {
      badge.className = 'status-badge fail';
      badge.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Falla Estructural';
    }
  }
  
  // Listeners
  inputR.addEventListener('input', () => { updateValues(); triggerTabDraw('lab'); });
  inputr.addEventListener('input', () => { updateValues(); triggerTabDraw('lab'); });
  selectLados.addEventListener('change', () => { updateValues(); triggerTabDraw('lab'); });
  inputOmega.addEventListener('input', () => { updateValues(); triggerTabDraw('lab'); });
  
  // Registrar el visualizador en el loop global
  window.canvasDrawers['lab'] = () => {
    const canvas = document.getElementById('canvas-lab');
    if (!canvas) return;
    
    updateValues();
    stopAllAnimations();
    
    function draw() {
      if (activeTabId !== 'lab') return;
      
      const ctx = getScaledContext(canvas);
      const w = canvas.width / (window.devicePixelRatio || 1);
      const h = canvas.height / (window.devicePixelRatio || 1);
      const cx = w / 2;
      const cy = h / 2;
      
      // Limpiar y rejilla
      ctx.clearRect(0, 0, w, h);
      drawGrid(ctx, w, h);
      
      // Factor de escala físico a píxeles dinámico (el radio R máximo llena el 43% de la menor dimensión del lienzo)
      const scale = (Math.min(w, h) * 0.43) / 20;
      const pxR = labR * scale;
      const pxr = labr * scale;
      const pxApotema = calcularApotema(labR, labLados) * scale;
      const seguro = esEstructuraSegura(labR, labr, labLados);
      
      // Incrementar rotación angular
      rotationAngle += (labOmega * 0.005);
      
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rotationAngle);
      
      // Dibujar Corona Circular (Área de material)
      ctx.fillStyle = seguro ? 'rgba(99, 102, 241, 0.25)' : 'rgba(244, 63, 94, 0.15)';
      ctx.strokeStyle = seguro ? '#6366f1' : '#f43f5e';
      ctx.lineWidth = 2.5;
      
      ctx.beginPath();
      ctx.arc(0, 0, pxR, 0, Math.PI * 2);
      ctx.arc(0, 0, pxr, 0, Math.PI * 2, true); // Reloj inverso para cavidad
      ctx.fill();
      ctx.stroke();
      
      // Dibujar acoplamiento central (Polígono Inscrito)
      ctx.strokeStyle = seguro ? '#ffffff' : '#cbd5e1';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let i = 0; i < labLados; i++) {
        const theta = (i * Math.PI * 2) / labLados;
        const x = pxR * Math.cos(theta);
        const y = pxR * Math.sin(theta);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.stroke();
      
      // Resaltar caras planas del acoplamiento
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.beginPath();
      for (let i = 0; i < labLados; i++) {
        const theta = (i * Math.PI * 2) / labLados;
        const x = pxR * Math.cos(theta);
        const y = pxR * Math.sin(theta);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      
      // Si hay falla, dibujar regiones cortadas
      if (!seguro) {
        ctx.fillStyle = 'rgba(244, 63, 94, 0.6)';
        ctx.beginPath();
        for (let i = 0; i < labLados; i++) {
          const theta1 = (i * Math.PI * 2) / labLados;
          const theta2 = ((i + 1) * Math.PI * 2) / labLados;
          const x1 = pxR * Math.cos(theta1);
          const y1 = pxR * Math.sin(theta1);
          const x2 = pxR * Math.cos(theta2);
          const y2 = pxR * Math.sin(theta2);
          
          // Ecuación de línea de cara del cuadrado
          // Si el radio interior supera la apotema, intersecta esta línea
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          // Arco que define el hueco interior
          ctx.arc(0, 0, pxr, theta2, theta1, true);
          ctx.closePath();
          ctx.fill();
          
          // Indicador visual de puntos de corte de falla
          const midTheta = (theta1 + theta2) / 2;
          const fx = pxr * Math.cos(midTheta);
          const fy = pxr * Math.sin(midTheta);
          ctx.fillStyle = '#f43f5e';
          ctx.beginPath();
          ctx.arc(fx, fy, 4, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      
      // Dibujar Apotema (línea radial ortogonal a una cara)
      ctx.strokeStyle = '#f59e0b';
      ctx.setLineDash([3, 3]);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(pxApotema, 0); // En rotación 0 es horizontal
      ctx.stroke();
      ctx.setLineDash([]);
      
      // Dibujar fuerzas centrífugas (Vectores parpadeantes en los vértices)
      if (labOmega > 0) {
        ctx.strokeStyle = '#10b981';
        ctx.fillStyle = '#10b981';
        ctx.lineWidth = 2;
        const arrowLength = (labOmega * 0.5) * scale;
        
        for (let i = 0; i < labLados; i++) {
          const theta = (i * Math.PI * 2) / labLados;
          const vx = pxR * Math.cos(theta);
          const vy = pxR * Math.sin(theta);
          const ex = (pxR + arrowLength) * Math.cos(theta);
          const ey = (pxR + arrowLength) * Math.sin(theta);
          
          // Línea del vector
          ctx.beginPath();
          ctx.moveTo(vx, vy);
          ctx.lineTo(ex, ey);
          ctx.stroke();
          
          // Cabeza de flecha
          ctx.save();
          ctx.translate(ex, ey);
          ctx.rotate(theta);
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(-6, -4);
          ctx.lineTo(-6, 4);
          ctx.closePath();
          ctx.fill();
          ctx.restore();
        }
      }
      
      // Dibujar vectores radio R (rojo) y r (azul)
      ctx.strokeStyle = '#f43f5e'; // R exterior
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(pxR * Math.cos(Math.PI / 6), pxR * Math.sin(Math.PI / 6));
      ctx.stroke();
      
      ctx.strokeStyle = '#6366f1'; // r interior
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(pxr * Math.cos(Math.PI / 3), pxr * Math.sin(Math.PI / 3));
      ctx.stroke();
      
      ctx.restore(); // Restaurar translate/rotate

      // --- NOMENCLATURA GEOMÉTRICA EN EL SIMULADOR LAB ---
      ctx.font = "bold 15px 'Outfit'";
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      // 1. Radio Exterior (R)
      const angleR = rotationAngle + Math.PI / 6;
      ctx.fillStyle = '#f43f5e';
      ctx.fillText("R", cx + (pxR + 15) * Math.cos(angleR), cy + (pxR + 15) * Math.sin(angleR));
      
      // 2. Radio Interior (r)
      if (labr > 0) {
        const angle_r = rotationAngle + Math.PI / 3;
        ctx.fillStyle = '#6366f1';
        ctx.fillText("r", cx + (pxr + 15) * Math.cos(angle_r), cy + (pxr + 15) * Math.sin(angle_r));
      }
      
      // 3. Apotema (a)
      const angleA = rotationAngle;
      ctx.fillStyle = '#f59e0b';
      ctx.fillText("a", cx + (pxApotema + 15) * Math.cos(angleA), cy + (pxApotema + 15) * Math.sin(angleA));
      
      // 4. Velocidad de Giro (w / omega)
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, 26, rotationAngle - 0.4, rotationAngle + 0.4);
      ctx.stroke();
      
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rotationAngle + 0.4);
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath();
      ctx.moveTo(26, 0);
      ctx.lineTo(22, -4);
      ctx.lineTo(30, -4);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      
      ctx.fillStyle = '#94a3b8';
      ctx.fillText("ω", cx + 36 * Math.cos(rotationAngle), cy + 36 * Math.sin(rotationAngle));
      
      // 5. Fuerza Centrífuga (Fc)
      if (labOmega > 0) {
        ctx.fillStyle = '#10b981';
        const arrowLength = (labOmega * 0.5) * scale;
        const angleF = rotationAngle;
        ctx.fillText("Fc", cx + (pxR + arrowLength + 16) * Math.cos(angleF), cy + (pxR + arrowLength + 16) * Math.sin(angleF));
      }
      
      // Añadir etiquetas fijas (Labels) en esquinas superiores
      ctx.font = "bold 12px 'Outfit'";
      ctx.fillStyle = '#f43f5e';
      ctx.fillText(`R = ${labR.toFixed(1)} cm (Radio Ext)`, 15, 25);
      ctx.fillStyle = '#6366f1';
      ctx.fillText(`r = ${labr.toFixed(1)} cm (Radio Int)`, 15, 45);
      ctx.fillStyle = '#f59e0b';
      ctx.fillText(`a = ${calcularApotema(labR, labLados).toFixed(2)} cm (Apotema)`, 15, 65);
      
      if (!seguro) {
        ctx.fillStyle = '#f43f5e';
        ctx.font = "bold 14px 'Outfit'";
        ctx.fillText(`FRACTURA DETECTADA (r > a)`, w - 210, 25);
      } else {
        ctx.fillStyle = '#10b981';
        ctx.font = "bold 14px 'Outfit'";
        ctx.fillText(`SOPORTE SEGURO`, w - 140, 25);
      }
      
      if (labOmega > 0) {
        animationFrameIds['lab'] = requestAnimationFrame(draw);
      }
    }
    draw();
  };
}

/*=== 3. CONTROLADOR: CLASIFICACIÓN (PESTAÑA 2) ===*/
function initClassification() {
  const cards = document.querySelectorAll('.class-card');
  const inputR = document.getElementById('input-R');
  const inputr = document.getElementById('input-r');
  const selectLados = document.getElementById('select-lados');
  const inputOmega = document.getElementById('input-omega');
  
  cards.forEach(card => {
    card.addEventListener('click', () => {
      // Remover active de todas las tarjetas
      cards.forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      
      const preset = card.getAttribute('data-preset');
      
      // Configurar valores
      if (preset === 'solid') {
        inputR.value = 10;
        inputr.value = 0;
        selectLados.value = 4;
        inputOmega.value = 10;
      } else if (preset === 'optimal') {
        inputR.value = 10;
        inputr.value = 7.07;
        selectLados.value = 4;
        inputOmega.value = 10;
      } else if (preset === 'thin') {
        inputR.value = 10;
        inputr.value = 8.5;
        selectLados.value = 4;
        inputOmega.value = 10;
      } else if (preset === 'ultrathin') {
        inputR.value = 10;
        inputr.value = 9.5;
        selectLados.value = 4;
        inputOmega.value = 10;
      }
      
      // Cambiar a la pestaña del Laboratorio e inicializar el dibujo
      const labTabBtn = document.getElementById('tab-btn-lab');
      labTabBtn.click();
    });
  });
}

/*=== 4. CONTROLADOR: ELEMENTOS (PESTAÑA 4) ===*/
let activeAnatomyElement = 'radio-ext';

function initAnatomy() {
  const items = document.querySelectorAll('.anatomy-item');
  
  items.forEach(item => {
    const selectHandler = () => {
      items.forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      activeAnatomyElement = item.getAttribute('data-element');
      triggerTabDraw('elements');
    };
    
    item.addEventListener('mouseenter', selectHandler);
    item.addEventListener('click', selectHandler);
  });
  
  window.canvasDrawers['elements'] = () => {
    const canvas = document.getElementById('canvas-elements');
    if (!canvas) return;
    
    const ctx = getScaledContext(canvas);
    const w = canvas.width / (window.devicePixelRatio || 1);
    const h = canvas.height / (window.devicePixelRatio || 1);
    const cx = w / 2;
    const cy = h / 2;
    
    ctx.clearRect(0, 0, w, h);
    drawGrid(ctx, w, h);
    
    const scale = (Math.min(w, h) * 0.43) / 10; // escala dinámica
    const pxR = 10 * scale;
    const pxr = 7.07 * scale;
    const pxApotema = pxR * Math.cos(Math.PI / 4);
    
    ctx.save();
    ctx.translate(cx, cy);
    
    // Opacidad atenuada si no está seleccionado
    const opacityCorona = (activeAnatomyElement === 'corona') ? 0.7 : 0.15;
    const opacityAcople = (activeAnatomyElement === 'acople') ? 0.6 : 0.15;
    
    // 1. Dibujar Corona Sólida
    ctx.fillStyle = `rgba(99, 102, 241, ${opacityCorona})`;
    ctx.strokeStyle = activeAnatomyElement === 'corona' ? '#6366f1' : 'rgba(99, 102, 241, 0.3)';
    ctx.lineWidth = activeAnatomyElement === 'corona' ? 3 : 1.5;
    ctx.beginPath();
    ctx.arc(0, 0, pxR, 0, Math.PI * 2);
    ctx.arc(0, 0, pxr, 0, Math.PI * 2, true);
    ctx.fill();
    ctx.stroke();
    
    // 2. Dibujar Acople Cuadrado
    ctx.strokeStyle = activeAnatomyElement === 'acople' ? '#10b981' : 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = activeAnatomyElement === 'acople' ? 3 : 1.5;
    ctx.fillStyle = `rgba(16, 185, 129, ${opacityAcople * 0.2})`;
    ctx.beginPath();
    for (let i = 0; i < 4; i++) {
      const theta = (i * Math.PI * 2) / 4;
      const x = pxR * Math.cos(theta);
      const y = pxR * Math.sin(theta);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    
    // 3. Resaltar Radio Exterior R
    if (activeAnatomyElement === 'radio-ext') {
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(pxR * Math.cos(Math.PI / 6), pxR * Math.sin(Math.PI / 6));
      ctx.stroke();
      
      // Círculo extremo de radio
      ctx.fillStyle = '#f43f5e';
      ctx.beginPath();
      ctx.arc(pxR * Math.cos(Math.PI / 6), pxR * Math.sin(Math.PI / 6), 6, 0, Math.PI * 2);
      ctx.fill();

      // Etiqueta R
      ctx.font = "bold 15px 'Outfit'";
      ctx.fillStyle = '#f43f5e';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText("R", (pxR + 15) * Math.cos(Math.PI / 6), (pxR + 15) * Math.sin(Math.PI / 6));
    }
    
    // 4. Resaltar Radio Interior r
    if (activeAnatomyElement === 'radio-int') {
      ctx.strokeStyle = '#a855f7';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(pxr * Math.cos(Math.PI / 3), pxr * Math.sin(Math.PI / 3));
      ctx.stroke();
      
      ctx.fillStyle = '#a855f7';
      ctx.beginPath();
      ctx.arc(pxr * Math.cos(Math.PI / 3), pxr * Math.sin(Math.PI / 3), 6, 0, Math.PI * 2);
      ctx.fill();

      // Etiqueta r
      ctx.font = "bold 15px 'Outfit'";
      ctx.fillStyle = '#a855f7';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText("r", (pxr + 15) * Math.cos(Math.PI / 3), (pxr + 15) * Math.sin(Math.PI / 3));
    }
    
    // 5. Resaltar Apotema a
    if (activeAnatomyElement === 'apotema') {
      // Línea apotema
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(pxApotema, 0);
      ctx.stroke();
      
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(pxApotema, 0, 6, 0, Math.PI * 2);
      ctx.fill();

      // Etiqueta a
      ctx.font = "bold 15px 'Outfit'";
      ctx.fillStyle = '#f59e0b';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText("a", pxApotema + 15, 0);
      
      // Dibujar ángulo de 45°
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(pxR * Math.cos(Math.PI / 4), pxR * Math.sin(Math.PI / 4));
      ctx.stroke();
      
      // Arco del ángulo
      ctx.beginPath();
      ctx.arc(0, 0, 30, 0, Math.PI / 4);
      ctx.stroke();
      
      ctx.font = "11px 'Plus Jakarta Sans'";
      ctx.fillStyle = '#f59e0b';
      ctx.fillText("45°", 35, 15);
    }
    
    // 6. Nomenclatura complementaria para corona y acople
    if (activeAnatomyElement === 'corona') {
      ctx.fillStyle = '#f8fafc';
      ctx.font = "bold 15px 'Outfit'";
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText("Corona (A)", 0, (pxR + pxr) / 2);
    }
    
    if (activeAnatomyElement === 'acople') {
      ctx.fillStyle = '#10b981';
      ctx.font = "bold 15px 'Outfit'";
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText("Acople", 0, -pxR - 18);
    }
    
    ctx.restore();
    
    // Título técnico interactivo
    ctx.font = "bold 14px 'Outfit'";
    ctx.fillStyle = '#ffffff';
    let detailText = '';
    if (activeAnatomyElement === 'radio-ext') detailText = 'Radio Exterior (R): Determina el torque centrífugo y límite del acople.';
    else if (activeAnatomyElement === 'radio-int') detailText = 'Radio Interior (r): Remueve masa cerca del eje central para optimizar costo.';
    else if (activeAnatomyElement === 'apotema') detailText = 'Apotema (a): R * cos(45°) = Límite físico para evitar fallas estructurales.';
    else if (activeAnatomyElement === 'corona') detailText = 'Corona Circular: Área de transferencia de torque y disipación de calor.';
    else if (activeAnatomyElement === 'acople') detailText = 'Polígono Inscrito: Sección geométrica de sujeción para transmisión de torque.';
    
    ctx.fillText(detailText, 15, h - 20);
  };
}

/*=== 5. CONTROLADOR: 12 EJERCICIOS INTERACTIVOS (PESTAÑA 6) ===*/
let activeExId = 1;
let activeStepIndex = 0;
const completedExercises = new Set();

const exercisesDatabase = {
  1: {
    title: "Área de Corona Circular Convencional",
    difficulty: "basico",
    statement: "Un volante de inercia de una prensa industrial tiene un radio exterior \\(R = 12\\text{ cm}\\) y un radio interior \\(r = 6\\text{ cm}\\). Determina el área sólida de la sección transversal.",
    pedagogicalHint: "El área representa la cantidad de material y masa del volante. Utiliza la fórmula directa de la corona circular.",
    steps: [
      {
        title: "Paso 1: Identificar los radios de diseño",
        desc: "El radio exterior es \\(R = 12\\text{ cm}\\) y el radio interior es \\(r = 6\\text{ cm}\\).",
        math: "Identificamos: \\\\[R = 12\\\\text{ cm}, \\\\quad r = 6\\\\text{ cm}\\\\]"
      },
      {
        title: "Paso 2: Aplicar la ecuación del área",
        desc: "Sustituye los valores en la ecuación: \\(A = \\pi(R^2 - r^2)\\).",
        math: "Planteamiento: \\\\[A = \\\\pi \\\\cdot (12^2 - 6^2) = \\\\pi \\\\cdot (144 - 36) = 108\\\\pi\\\\text{ cm}^2\\\\]"
      },
      {
        title: "Paso 3: Calcular el valor final",
        desc: "Multiplica por \\(\\pi \\approx 3.1416\\) para obtener el resultado decimal final.",
        math: "Cálculo: \\\\[A \\\\approx 108 \\\\cdot 3.14159 = 339.29\\\\text{ cm}^2\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 12;
      const pxR = 12 * scale;
      const pxr = 6 * scale;
      ctx.translate(w / 2, h / 2);
      
      // Step 1: radios
      ctx.strokeStyle = 'rgba(255,255,255,0.1)';
      ctx.beginPath();
      ctx.arc(0, 0, pxR, 0, Math.PI * 2);
      ctx.stroke();
      
      ctx.fillStyle = 'rgba(99, 102, 241, 0.1)';
      ctx.beginPath();
      ctx.arc(0, 0, pxR, 0, Math.PI * 2);
      ctx.arc(0, 0, pxr, 0, Math.PI * 2, true);
      ctx.fill();
      
      if (stepIndex >= 0) {
        ctx.strokeStyle = '#f43f5e'; // R
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(pxR * Math.cos(Math.PI/6), pxR * Math.sin(Math.PI/6)); ctx.stroke();
        ctx.fillStyle = '#f43f5e'; ctx.font = "12px 'Outfit'"; ctx.fillText("R = 12 cm", pxR*0.5, -5);
      }
      if (stepIndex >= 1) {
        ctx.strokeStyle = '#6366f1'; // r
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(pxr * Math.cos(-Math.PI/4), pxr * Math.sin(-Math.PI/4)); ctx.stroke();
        ctx.fillStyle = '#6366f1'; ctx.fillText("r = 6 cm", pxr*0.5, -20);
      }
      if (stepIndex >= 2) {
        ctx.fillStyle = 'rgba(16, 185, 129, 0.2)'; // Relleno de área total
        ctx.beginPath();
        ctx.arc(0, 0, pxR, 0, Math.PI * 2);
        ctx.arc(0, 0, pxr, 0, Math.PI * 2, true);
        ctx.fill();
        
        ctx.fillStyle = '#10b981';
        ctx.font = "bold 14px 'Outfit'";
        ctx.fillText("Área = 339.29 cm²", -55, 5);
      }
    }
  },
  2: {
    title: "Momento Polar de Disco Sólido",
    difficulty: "basico",
    statement: "Determina el momento polar de inercia \\(J\\) para un disco sólido de radio exterior \\(R = 10\\text{ cm}\\) (espesor interior \\(r = 0\\)).",
    pedagogicalHint: "Un disco sólido es una corona circular con radio interior cero. Representa el límite superior de inercia pero sin ahorro de material.",
    steps: [
      {
        title: "Paso 1: Establecer los parámetros",
        desc: "Para un disco sólido, el radio interior es cero: \\(R = 10\\text{ cm}\\) y \\(r = 0\\text{ cm}\\).",
        math: "Datos: \\\\[R = 10\\\\text{ cm}, \\\\quad r = 0\\\\text{ cm}\\\\]"
      },
      {
        title: "Paso 2: Aplicar la fórmula de inercia polar",
        desc: "La ecuación se reduce a: \\(J = \\frac{\\pi}{2} R^4\\).",
        math: "Fórmula: \\\\[J = \\\\frac{\\\\pi}{2} \\\\cdot (10)^4 = \\\\frac{\\\\pi}{2} \\\\cdot 10000 = 5000\\\\pi\\\\text{ cm}^4\\\\]"
      },
      {
        title: "Paso 3: Obtener el valor final",
        desc: "Calcula el valor numérico decimal final.",
        math: "Resultado: \\\\[J \\\\approx 5000 \\\\cdot 3.141592 = 15707.96\\\\text{ cm}^4\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 10;
      const pxR = 10 * scale;
      ctx.translate(w / 2, h / 2);
      
      // Círculo sólido
      ctx.fillStyle = 'rgba(99, 102, 241, 0.2)';
      ctx.strokeStyle = '#6366f1';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, 0, pxR, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      
      if (stepIndex >= 1) {
        ctx.strokeStyle = '#f43f5e';
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(pxR, 0); ctx.stroke();
        ctx.fillStyle = '#f43f5e'; ctx.font = "12px 'Outfit'"; ctx.fillText("R = 10 cm", 40, -10);
      }
      
      if (stepIndex >= 2) {
        // Flechas giratorias indicando inercia
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, pxR + 15, -Math.PI/4, Math.PI/4);
        ctx.stroke();
        ctx.fillStyle = '#10b981';
        ctx.beginPath(); ctx.moveTo(pxR+20, 20); ctx.lineTo(pxR+15, 30); ctx.lineTo(pxR+7, 20); ctx.closePath(); ctx.fill();
        ctx.fillText("J = 15,708 cm⁴", -45, 5);
      }
    }
  },
  3: {
    title: "Apotema de Acoplamiento Cuadrado",
    difficulty: "basico",
    statement: "Un volante de inercia con radio exterior \\(R = 15\\text{ cm}\\) tiene un eje cuadrado inscrito. Calcula la apotema \\(a\\) de dicho acople.",
    pedagogicalHint: "La apotema representa el límite máximo seguro al que puede expandirse el radio interior antes de fallar.",
    steps: [
      {
        title: "Paso 1: Identificar el número de lados y ángulo",
        desc: "Para un acople de sección cuadrada, el polígono inscrito tiene 4 lados.",
        math: "Lados: \\\\[n = 4\\\\text{ lados}\\\\]"
      },
      {
        title: "Paso 2: Aplicar relación trigonométrica",
        desc: "La apotema de un cuadrado inscrito es: \\(a = R \\cos(45^\\circ)\\).",
        math: "Trigonometría: \\\\[a = 15 \\\\cdot \\\\cos(45^\\\\circ) = 15 \\\\cdot \\\\frac{\\\\sqrt{2}}{2}\\\\]"
      },
      {
        title: "Paso 3: Obtener el valor de falla límite",
        desc: "Calcula el valor numérico en centímetros.",
        math: "Resultado: \\\\[a \\\\approx 15 \\\\cdot 0.7071 = 10.61\\\\text{ cm}\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 15;
      const pxR = 15 * scale;
      const pxA = 10.61 * scale;
      ctx.translate(w / 2, h / 2);
      
      // Círculo exterior
      ctx.strokeStyle = 'rgba(255,255,255,0.15)';
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.stroke();
      
      // Cuadrado inscrito
      ctx.strokeStyle = '#6366f1';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for(let i=0; i<4; i++) {
        const t = i * Math.PI/2;
        ctx.lineTo(pxR*Math.cos(t), pxR*Math.sin(t));
      }
      ctx.closePath(); ctx.stroke();
      
      if (stepIndex >= 1) {
        // Radio exterior R
        ctx.strokeStyle = '#f43f5e';
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(pxR*Math.cos(Math.PI/4), pxR*Math.sin(Math.PI/4)); ctx.stroke();
      }
      if (stepIndex >= 2) {
        // Apotema a
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(pxA, 0); ctx.stroke();
        ctx.fillStyle = '#f59e0b'; ctx.font = "12px 'Outfit'"; ctx.fillText("a = 10.61 cm", pxA*0.5, -5);
      }
    }
  },
  4: {
    title: "Perímetro de Enfriamiento Térmico",
    difficulty: "basico",
    statement: "Un freno de disco tipo corona circular posee un radio exterior \\(R = 8\\text{ cm}\\) y un radio interior óptimo \\(r = 5.66\\text{ cm}\\). Calcula su perímetro total de enfriamiento.",
    pedagogicalHint: "El perímetro expuesto al aire es la suma de los perímetros exterior e interior, determinantes para la disipación térmica.",
    steps: [
      {
        title: "Paso 1: Sumar los radios del componente",
        desc: "Identificamos los radios: \\(R = 8\\text{ cm}\\) y \\(r = 5.66\\text{ cm}\\).",
        math: "Suma: \\\\[R + r = 8 + 5.66 = 13.66\\\\text{ cm}\\\\]"
      },
      {
        title: "Paso 2: Aplicar fórmula de perímetros concéntricos",
        desc: "La longitud total expuesta es: \\(P = 2\\pi(R + r)\\).",
        math: "Fórmula: \\\\[P = 2 \\\\cdot \\\\pi \\\\cdot 13.66 = 27.32\\\\pi\\\\text{ cm}\\\\]"
      },
      {
        title: "Paso 3: Obtener valor final expuesto",
        desc: "Calcula el valor numérico en centímetros para estimar convección.",
        math: "Resultado: \\\\[P \\\\approx 27.32 \\\\cdot 3.14159 = 85.83\\\\text{ cm}\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 8;
      const pxR = 8 * scale;
      const pxr = 5.66 * scale;
      ctx.translate(w / 2, h / 2);
      
      // Corona
      ctx.fillStyle = 'rgba(99, 102, 241, 0.15)';
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.arc(0,0, pxr, 0, Math.PI*2, true); ctx.fill();
      
      // Bordes
      ctx.strokeStyle = stepIndex >= 1 ? '#f43f5e' : 'rgba(255,255,255,0.1)';
      ctx.lineWidth = stepIndex >= 1 ? 2.5 : 1;
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.stroke();
      
      ctx.strokeStyle = stepIndex >= 1 ? '#6366f1' : 'rgba(255,255,255,0.1)';
      ctx.lineWidth = stepIndex >= 1 ? 2.5 : 1;
      ctx.beginPath(); ctx.arc(0,0, pxr, 0, Math.PI*2); ctx.stroke();
      
      if (stepIndex >= 2) {
        ctx.fillStyle = '#10b981';
        ctx.font = "bold 13px 'Outfit'";
        ctx.fillText("Perímetro Total = 85.83 cm", -75, 5);
      }
    }
  },
  5: {
    title: "Optimización de Radio Interior dado Área",
    difficulty: "intermedio",
    statement: "Se desea fabricar un engranaje anular con área de material \\(A = 150\\text{ cm}^2\\) y radio exterior \\(R = 10\\text{ cm}\\). Determina el radio interior \\(r\\) del agujero central.",
    pedagogicalHint: "Este problema requiere despejar algebraicamente el radio interior \\(r\\) a partir de la fórmula del área.",
    steps: [
      {
        title: "Paso 1: Plantear la ecuación del área",
        desc: "Sustituimos el Área \\(A = 150\\) y el radio \\(R = 10\\) en la ecuación.",
        math: "Ecuación: \\\\[150 = \\\\pi(10^2 - r^2) \\\\implies 100 - r^2 = \\\\frac{150}{\\\\pi} \\\\approx 47.75\\\\]"
      },
      {
        title: "Paso 2: Despejar el radio interior al cuadrado",
        desc: "Despejamos el término \\(r^2\\).",
        math: "Despeje: \\\\[r^2 = 100 - 47.75 = 52.25\\\\]"
      },
      {
        title: "Paso 3: Extraer la raíz y concluir seguridad",
        desc: "Calculamos \\(r = \\sqrt{52.25}\\) y evaluamos si supera el límite de seguridad cuadrada (\\(a = 7.07\\text{ cm}\\)).",
        math: "Cálculo: \\\\[r = \\\\sqrt{52.25} \\\\approx 7.23\\\\text{ cm}\\\\] \\\\[\\\\text{Como } r = 7.23 > a = 7.07 \\\\implies \\\\text{FALLA ESTRUCTURAL}\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 10;
      const pxR = 10 * scale;
      const pxr = 7.23 * scale;
      const pxA = 7.07 * scale;
      ctx.translate(w / 2, h / 2);
      
      // Corona
      ctx.fillStyle = stepIndex === 2 ? 'rgba(244,63,94,0.15)' : 'rgba(99,102,241,0.2)';
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.arc(0,0, pxr, 0, Math.PI*2, true); ctx.fill();
      
      ctx.strokeStyle = '#6366f1';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.arc(0,0, pxr, 0, Math.PI*2); ctx.stroke();
      
      // Cuadrado acople
      ctx.strokeStyle = 'rgba(255,255,255,0.2)';
      ctx.beginPath();
      for(let i=0; i<4; i++) {
        const t = i * Math.PI/2;
        ctx.lineTo(pxR*Math.cos(t), pxR*Math.sin(t));
      }
      ctx.closePath(); ctx.stroke();
      
      if (stepIndex >= 1) {
        ctx.fillStyle = '#6366f1';
        ctx.font = "11px 'Outfit'";
        ctx.fillText(`r = 7.23 cm`, pxr * 0.7, -10);
      }
      if (stepIndex >= 2) {
        // Mostrar intersección cortada en rojo
        ctx.fillStyle = '#f43f5e';
        ctx.font = "bold 13px 'Outfit'";
        ctx.fillText("Falla: r (7.23) > apotema (7.07)", -90, 5);
        ctx.strokeStyle = '#f43f5e';
        ctx.beginPath(); ctx.arc(0,0, pxr, 0, Math.PI*2); ctx.stroke();
      }
    }
  },
  6: {
    title: "Momento Polar de Corona Óptima",
    difficulty: "intermedio",
    statement: "Calcula el momento polar de inercia \\(J\\) para un volante de corona de diseño óptimo con radio exterior \\(R = 10\\text{ cm}\\) y radio interior \\(r = 7.07\\text{ cm}\\).",
    pedagogicalHint: "La corona óptima reduce a la mitad el área sólida del disco original conservando alta resistencia rotacional.",
    steps: [
      {
        title: "Paso 1: Calcular el área de la corona óptima",
        desc: "Calculamos el área transversal del anillo: \\(A = \\pi(R^2 - r^2)\\).",
        math: "Área: \\\\[A = \\\\pi(10^2 - 7.07^2) = \\\\pi(100 - 50) = 50\\\\pi \\\\approx 157.08\\\\text{ cm}^2\\\\]"
      },
      {
        title: "Paso 2: Calcular el momento polar de inercia",
        desc: "Usamos la fórmula simplificada \\(J = \\frac{A}{2}(R^2 + r^2)\\).",
        math: "J: \\\\[J = \\\\frac{50\\\\pi}{2} (100 + 50) = 25\\\\pi \\\\cdot 150 = 3750\\\\pi\\\\text{ cm}^4\\\\]"
      },
      {
        title: "Paso 3: Comparar la eficiencia rotacional",
        desc: "El resultado decimal es \\(11780.97\\text{ cm}^4\\). Conserva el 75% de inercia del disco sólido original con solo 50% de la masa.",
        math: "Resultado: \\\\[J \\\\approx 11780.97\\\\text{ cm}^4\\\\text{ (Eficiencia = 75 cm}^2\\\\text{ por unidad de peso)}\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 10;
      const pxR = 10 * scale;
      const pxr = 7.07 * scale;
      ctx.translate(w / 2, h / 2);
      
      ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.arc(0,0, pxr, 0, Math.PI*2, true); ctx.fill();
      
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.arc(0,0, pxr, 0, Math.PI*2); ctx.stroke();
      
      if (stepIndex >= 2) {
        ctx.fillStyle = '#10b981';
        ctx.font = "bold 13px 'Outfit'";
        ctx.fillText("Masa: -50% | Inercia: 75%", -65, 5);
      }
    }
  },
  7: {
    title: "Apotema de Acoplamiento Hexagonal",
    difficulty: "intermedio",
    statement: "Un eje de sección hexagonal regular se acopla a un volante con radio exterior \\(R = 12\\text{ cm}\\). Determina la apotema \\(a\\) y compara con un acople cuadrado.",
    pedagogicalHint: "A mayor número de lados en el acople poligonal, la apotema aumenta, permitiendo un radio interior más grande.",
    steps: [
      {
        title: "Paso 1: Aplicar parámetros de hexágono",
        desc: "Para un hexágono, el número de lados es \\(n = 6\\). El ángulo central medio es \\(30^\\circ\\) (\\(\\pi/6\\)).",
        math: "Ángulo: \\\\[\\\\theta = \\\\frac{180^\\\\circ}{6} = 30^\\\\circ\\\\]"
      },
      {
        title: "Paso 2: Calcular la apotema hexagonal",
        desc: "La apotema es \\(a = R \\cos(30^\\circ)\\).",
        math: "Cálculo: \\\\[a = 12 \\\\cdot \\\\cos(30^\\\\circ) = 12 \\\\cdot 0.866 = 10.39\\\\text{ cm}\\\\]"
      },
      {
        title: "Paso 3: Analizar beneficio de diseño",
        desc: "El acople hexagonal permite un radio interior límite mayor (\\(10.39\\text{ cm}\\)) que el cuadrado (\\(8.49\\text{ cm}\\)) para el mismo radio exterior.",
        math: "Comparación: \\\\[a_{\\\\text{hex}} = 10.39\\\\text{ cm} > a_{\\\\text{cuad}} = 8.49\\\\text{ cm}\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 12;
      const pxR = 12 * scale;
      const pxA = 10.39 * scale;
      ctx.translate(w / 2, h / 2);
      
      // Hexágono
      ctx.strokeStyle = '#a855f7';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for(let i=0; i<6; i++) {
        const t = i * Math.PI / 3;
        ctx.lineTo(pxR*Math.cos(t), pxR*Math.sin(t));
      }
      ctx.closePath(); ctx.stroke();
      
      if (stepIndex >= 1) {
        ctx.strokeStyle = '#f43f5e';
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(pxR*Math.cos(Math.PI/6), pxR*Math.sin(Math.PI/6)); ctx.stroke();
      }
      if (stepIndex >= 2) {
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(pxA, 0); ctx.stroke();
        ctx.fillStyle = '#f59e0b';
        ctx.font = "12px 'Outfit'";
        ctx.fillText(`a = 10.39 cm`, pxA * 0.5, -5);
      }
    }
  },
  8: {
    title: "Balance de Ahorro de Masa vs Pérdida de Inercia",
    difficulty: "intermedio",
    statement: "Evalúa cuantitativamente un volante con radios \\(R = 10\\text{ cm}\\) y \\(r = 6\\text{ cm}\\) determinando su ahorro de masa y pérdida de inercia polar.",
    pedagogicalHint: "Determina si el porcentaje de masa ahorrada justifica la reducción del momento de inercia del sistema.",
    steps: [
      {
        title: "Paso 1: Calcular porcentaje de ahorro de masa",
        desc: "El área ahorrada es proporcional a \\(r^2 / R^2\\).",
        math: "Ahorro Masa: \\\\[\\\\%\\\\text{Masa} = \\\\frac{6^2}{10^2} \\\\cdot 100\\% = 36\\%\\\\]"
      },
      {
        title: "Paso 2: Calcular porcentaje de pérdida de inercia",
        desc: "La inercia reducida es proporcional a \\(r^4 / R^4\\).",
        math: "Pérdida Inercia: \\\\[\\\\%\\\\text{Inercia Perdida} = \\\\frac{6^4}{10^4} \\\\cdot 100\\% = \\\\frac{1296}{10000} \\\\cdot 100\\% = 12.96\\%\\\\]"
      },
      {
        title: "Paso 3: Determinar el índice de eficiencia",
        desc: "La inercia retenida es del \\(87.04\\%\\). Reducimos el \\(36.0\\%\\) del peso perdiendo solo el \\(13.0\\%\\) de inercia. Un diseño altamente eficiente.",
        math: "Eficiencia: \\\\[\\\\text{Retención J} = 87.04\\%, \\\\quad \\\\text{Masa} = 64\\%\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      ctx.translate(w / 2, h / 2);
      
      const chartW = Math.min(w * 0.6, 360);
      const chartH = Math.min(h * 0.6, 220);
      
      // Dibujar gráfico de barras en el canvas
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-chartW / 2, -chartH / 2, chartW, chartH);
      
      const barW = chartW * 0.16;
      const barSpacing = chartW * 0.25;
      
      ctx.fillStyle = '#6366f1';
      // Barra masa (36% ahorro -> 64% peso)
      const hM = stepIndex >= 0 ? 0.64 * (chartH - 60) : (chartH - 60);
      ctx.fillRect(-barSpacing, (chartH / 2 - 30) - hM, barW, hM);
      
      ctx.fillStyle = '#10b981';
      // Barra inercia (87.04% retención)
      const hI = stepIndex >= 1 ? 0.87 * (chartH - 60) : (chartH - 60);
      ctx.fillRect(barSpacing - barW, (chartH / 2 - 30) - hI, barW, hI);
      
      ctx.fillStyle = '#ffffff';
      ctx.font = "bold 13px 'Outfit'";
      ctx.fillText("Masa", -barSpacing + barW * 0.1, chartH / 2 - 10);
      ctx.fillText("Inercia", barSpacing - barW * 0.8, chartH / 2 - 10);
      
      ctx.font = "bold 14px 'Outfit'";
      if (stepIndex >= 0) ctx.fillText(`${Math.round(hM / (chartH - 60) * 100)}%`, -barSpacing + barW * 0.1, (chartH / 2 - 30) - hM - 8);
      if (stepIndex >= 1) ctx.fillText(`${Math.round(hI / (chartH - 60) * 100)}%`, barSpacing - barW * 0.8, (chartH / 2 - 30) - hI - 8);
    }
  },
  9: {
    title: "Cálculo Dinámico para Almacenamiento de Energía",
    difficulty: "avanzado",
    statement: "Un volante de inercia de acero (densidad \\(\\rho = 7800\\text{ kg/m}^3\\)) de espesor \\(h = 5\\text{ cm}\\) y radio exterior \\(R = 20\\text{ cm}\\) debe almacenar \\(1000\\text{ J}\\) de energía a \\(50\\text{ rad/s}\\). Halla el radio interior \\(r\\) adecuado.",
    pedagogicalHint: "Relaciona la energía cinética rotacional \\(E_k = \\frac{1}{2} J \\omega^2\\) con las dimensiones y densidad de la corona circular.",
    steps: [
      {
        title: "Paso 1: Determinar el momento polar J requerido",
        desc: "Despejamos \\(J\\) de la fórmula de la energía cinética rotacional.",
        math: "Despeje J: \\\\[E_k = \\\\frac{1}{2} J \\\\omega^2 \\\\implies 1000 = \\\\frac{1}{2} J \\\\cdot 50^2 \\\\implies J = \\\\frac{2000}{2500} = 0.8\\\\text{ kg}\\\\cdot\\\\text{m}^2 = 8,000,000\\\\text{ cm}^4\\\\]"
      },
      {
        title: "Paso 2: Vincular J con la masa y radios",
        desc: "El momento de inercia de una corona circular es \\(J = \\frac{1}{2} M (R^2 + r^2)\\) y la masa es \\(M = \\rho \\pi(R^2 - r^2) h\\).",
        math: "Fórmula combinada: \\\\[J = \\\\frac{\\\\pi \\\\rho h}{2} (R^4 - r^4) \\\\implies 8,000,000 = \\\\frac{\\\\pi \\\\cdot 0.0078 \\\\cdot 5}{2} (20^4 - r^4)\\\\]"
      },
      {
        title: "Paso 3: Despejar y verificar estabilidad",
        desc: "Resolvemos la ecuación para \\(r\\).",
        math: "Solución: \\\\[R^4 - r^4 \\\\approx 130,580 \\\\implies r^4 = 160,000 - 130,580 = 29,420\\\\text{ cm}^4\\\\] \\\\[r = (29,420)^{1/4} \\\\approx 13.08\\\\text{ cm} \\\\le a = 14.14\\\\text{ cm} \\\\quad \\\\text{(SEGURO)}\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 20;
      const pxR = 20 * scale;
      const pxr = 13.08 * scale;
      ctx.translate(w / 2, h / 2);
      
      ctx.fillStyle = 'rgba(99, 102, 241, 0.25)';
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.arc(0,0, pxr, 0, Math.PI*2, true); ctx.fill();
      
      ctx.strokeStyle = '#6366f1';
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.arc(0,0, pxr, 0, Math.PI*2); ctx.stroke();
      
      if (stepIndex >= 2) {
        ctx.fillStyle = '#10b981';
        ctx.font = "bold 13px 'Outfit'";
        ctx.fillText("Diseño Seguro: r = 13.08 cm", -80, 5);
      }
    }
  },
  10: {
    title: "Esfuerzo Centrífugo y Velocidad Límite",
    difficulty: "avanzado",
    statement: "Un volante de inercia con \\(R = 20\\text{ cm}\\) y \\(r = 15\\text{ cm}\\) está hecho de acero con densidad \\(7850\\text{ kg/m}^3\\). Si el límite de fluencia del material es \\(\\sigma_y = 250\\text{ MPa}\\), determina la velocidad máxima de giro.",
    pedagogicalHint: "El esfuerzo centrífugo tangencial en la corona circular limita la velocidad de giro para evitar fallas mecánicas.",
    steps: [
      {
        title: "Paso 1: Identificar la ecuación de esfuerzo tangencial máximo",
        desc: "Para un anillo rotatorio de pared delgada, el esfuerzo máximo es aproximado por: \\(\\sigma_t \\approx \\rho \\omega^2 R^2\\).",
        math: "Ecuación: \\\\[\\\\sigma_t = \\\\rho \\\\omega^2 R^2 \\\\le \\\\sigma_y\\\\]"
      },
      {
        title: "Paso 2: Reemplazar valores y despejar omega",
        desc: "Sustituimos la densidad \\(7850\\text{ kg/m}^3\\) y el radio en metros (\\(0.2\\text{ m}\\)).",
        math: "Despeje: \\\\[250 \\\\times 10^6 \\\\ge 7850 \\\\cdot \\\\omega^2 \\\\cdot (0.2)^2 \\\\implies 250 \\\\times 10^6 \\\\ge 314 \\\\cdot \\\\omega^2\\\\]"
      },
      {
        title: "Paso 3: Obtener la velocidad angular límite",
        desc: "Calculamos el valor de \\(\\omega\\) en rad/s.",
        math: "Resultado: \\\\[\\\\omega^2 \\\\le 796,178 \\\\implies \\\\omega \\\\le 892.28\\\\text{ rad/s}\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 20;
      const pxR = 20 * scale;
      const pxr = 15 * scale;
      ctx.translate(w / 2, h / 2);
      
      ctx.fillStyle = 'rgba(244, 63, 94, 0.1)';
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.arc(0,0, pxr, 0, Math.PI*2, true); ctx.fill();
      
      ctx.strokeStyle = '#f43f5e';
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.arc(0,0, pxr, 0, Math.PI*2); ctx.stroke();
      
      if (stepIndex >= 2) {
        ctx.fillStyle = '#f43f5e';
        ctx.font = "bold 13px 'Outfit'";
        ctx.fillText("Límite: 892 rad/s (~8520 RPM)", -90, 5);
      }
    }
  },
  11: {
    title: "Optimización Multiobjetivo: Inercia y Disipación",
    difficulty: "avanzado",
    statement: "Un equipo de diseño industrial busca maximizar la inercia retenida y el perímetro térmico con masa reducida. Demuestra que \\(r/R = 0.707\\) es el punto óptimo bajo peso simétrico.",
    pedagogicalHint: "Plantea la derivada de la eficiencia de inercia por unidad de área para encontrar el máximo absoluto.",
    steps: [
      {
        title: "Paso 1: Plantear la función de eficiencia específica",
        desc: "La inercia por unidad de área es \\(J / A = \\frac{1}{2}(R^2 + r^2)\\).",
        math: "Eficiencia: \\\\[\\\\eta = \\\\frac{J}{A} = \\\\frac{R^2 + r^2}{2}\\\\]"
      },
      {
        title: "Paso 2: Definir restricción de masa del 50%",
        desc: "Para ahorrar exactamente el 50% de material, establecemos el área como la mitad del círculo sólido.",
        math: "Restricción: \\\\[A_{\\\\text{corona}} = 0.5 \\\\cdot A_{\\\\text{sólido}} \\\\implies \\\\pi(R^2 - r^2) = 0.5 \\\\pi R^2 \\\\implies r^2 = 0.5 R^2\\\\]"
      },
      {
        title: "Paso 3: Obtener la relación óptima",
        desc: "Despejamos la relación \\(r/R\\) para cumplir con el balance simétrico.",
        math: "Solución: \\\\[\\\\frac{r^2}{R^2} = 0.5 \\\\implies \\\\frac{r}{R} = \\\\sqrt{0.5} \\\\approx 0.7071\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      ctx.translate(w / 2, h / 2);
      
      const graphW = Math.min(w * 0.6, 320);
      const graphH = Math.min(h * 0.5, 200);
      
      // Ejes coordenados
      ctx.strokeStyle = 'rgba(255,255,255,0.2)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-graphW / 2, graphH / 2);
      ctx.lineTo(graphW / 2, graphH / 2);
      ctx.moveTo(-graphW / 2, -graphH / 2);
      ctx.lineTo(-graphW / 2, graphH / 2);
      ctx.stroke();
      
      // Dibujar curva de Pareto / optimización (Eficiencia)
      ctx.strokeStyle = '#6366f1';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      for (let x = -graphW / 2; x <= graphW / 2; x++) {
        const rRatio = (x + graphW / 2) / graphW; // 0 a 1
        const efficiency = (1 - Math.pow(rRatio, 4)) * (rRatio * rRatio); // J_retention * Ahorro_masa
        const y = graphH / 2 - efficiency * (graphH * 1.5); // escala vertical
        if (x === -graphW / 2) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      
      if (stepIndex >= 2) {
        // Línea en x = 0.707
        const ox = -graphW / 2 + 0.707 * graphW;
        const oy = graphH / 2 - 0.375 * (graphH * 1.5);
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.arc(ox, oy, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.font = "bold 12px 'Outfit'";
        ctx.fillText("Óptimo = 0.707", ox - 40, oy - 15);
      }
    }
  },
  12: {
    title: "Volante de Inercia de Brazos Reforzados",
    difficulty: "avanzado",
    statement: "Un volante se compone de un aro exterior (corona) y 4 brazos rectangulares radiales de masa total \\(M_b = 5\\text{ kg}\\). Si el aro tiene \\(R=20\\text{ cm}\\), \\(r=16\\text{ cm}\\) y masa \\(M_a = 15\\text{ kg}\\), calcula el momento de inercia total.",
    pedagogicalHint: "Divide el sistema en componentes discretos utilizando el teorema de superposición lineal para inercias.",
    steps: [
      {
        title: "Paso 1: Calcular la inercia del aro exterior (corona)",
        desc: "Usamos la fórmula para la corona circular.",
        math: "Inercia Aro: \\\\[J_a = \\\\frac{1}{2} M_a (R^2 + r^2) = \\\\frac{1}{2} \\\\cdot 15 \\\\cdot (20^2 + 16^2) = 7.5 \\\\cdot (400 + 256) = 4920\\\\text{ kg}\\\\cdot\\\\text{cm}^2\\\\]"
      },
      {
        title: "Paso 2: Calcular la inercia de los 4 brazos radiales",
        desc: "Cada brazo se modela como una barra delgada que rota sobre un extremo: \\(J_b = \\frac{1}{3} m_b L^2\\). Su longitud es \\(L = r = 16\\text{ cm}\\).",
        math: "Inercia Brazos: \\\\[J_{brazos} = 4 \\\\cdot \\\\left(\\\\frac{1}{3} \\\\cdot \\\\frac{M_b}{4} \\\\cdot r^2\\\\right) = \\\\frac{1}{3} M_b r^2 = \\\\frac{1}{3} \\\\cdot 5 \\\\cdot 16^2 = \\\\frac{1280}{3} \\\\approx 426.67\\\\text{ kg}\\\\cdot\\\\text{cm}^2\\\\]"
      },
      {
        title: "Paso 3: Obtener la inercia combinada total",
        desc: "Sumamos linealmente ambos aportes inerciales.",
        math: "Inercia Total: \\\\[J_{total} = J_a + J_{brazos} = 4920 + 426.67 = 5346.67\\\\text{ kg}\\\\cdot\\\\text{cm}^2\\\\]"
      }
    ],
    draw: (ctx, w, h, stepIndex) => {
      const scale = (Math.min(w, h) * 0.43) / 20;
      const pxR = 20 * scale;
      const pxr = 16 * scale;
      ctx.translate(w / 2, h / 2);
      
      // Corona
      ctx.fillStyle = 'rgba(99, 102, 241, 0.2)';
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.arc(0,0, pxr, 0, Math.PI*2, true); ctx.fill();
      
      ctx.strokeStyle = '#6366f1';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(0,0, pxR, 0, Math.PI*2); ctx.stroke();
      ctx.beginPath(); ctx.arc(0,0, pxr, 0, Math.PI*2); ctx.stroke();
      
      // Brazos
      ctx.strokeStyle = stepIndex >= 1 ? '#10b981' : 'rgba(255,255,255,0.2)';
      ctx.lineWidth = stepIndex >= 1 ? 4 : 2;
      ctx.beginPath();
      ctx.moveTo(-pxr, 0); ctx.lineTo(pxr, 0);
      ctx.moveTo(0, -pxr); ctx.lineTo(0, pxr);
      ctx.stroke();
      
      if (stepIndex >= 2) {
        ctx.fillStyle = '#10b981';
        ctx.font = "bold 13px 'Outfit'";
        ctx.fillText(`J total = 5347 kg·cm²`, -65, pxR + 20);
      }
    }
  }
};

function initExercises() {
  const container = document.getElementById('exercise-list-container');
  const btnPrev = document.getElementById('btn-ex-prev');
  const btnNext = document.getElementById('btn-ex-next');
  const stepIndicator = document.getElementById('ex-step-indicator');
  
  // Generar lista de botones de ejercicios E1 a E12
  for (let i = 1; i <= 12; i++) {
    const btn = document.createElement('button');
    btn.className = `ex-btn ${i === 1 ? 'active' : ''}`;
    btn.id = `btn-ex-${i}`;
    btn.textContent = `E${i}`;
    btn.addEventListener('click', () => {
      document.querySelectorAll('.ex-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      loadExercise(i);
    });
    container.appendChild(btn);
  }
  
  // Listeners de navegación de pasos
  btnPrev.addEventListener('click', () => {
    if (activeStepIndex > 0) {
      activeStepIndex--;
      updateStepUI();
    }
  });
  
  btnNext.addEventListener('click', () => {
    const ex = exercisesDatabase[activeExId];
    if (activeStepIndex < ex.steps.length - 1) {
      activeStepIndex++;
      updateStepUI();
    } else {
      // Marcar ejercicio como completado
      completedExercises.add(activeExId);
      document.getElementById(`btn-ex-${activeExId}`).classList.add('completed');
      alert(`🎉 ¡Ejercicio ${activeExId} completado con éxito!`);
    }
  });
  
  // Carga inicial
  loadExercise(1);
  
  window.canvasDrawers['exercises'] = () => {
    const canvas = document.getElementById('canvas-exercises');
    if (!canvas) return;
    
    const ctx = getScaledContext(canvas);
    const w = canvas.width / (window.devicePixelRatio || 1);
    const h = canvas.height / (window.devicePixelRatio || 1);
    
    ctx.clearRect(0, 0, w, h);
    drawGrid(ctx, w, h);
    
    ctx.save();
    const ex = exercisesDatabase[activeExId];
    if (ex && ex.draw) {
      ex.draw(ctx, w, h, activeStepIndex);
    }
    ctx.restore();
  };
}

function loadExercise(id) {
  activeExId = id;
  activeStepIndex = 0;
  
  const ex = exercisesDatabase[id];
  
  // Dificultad
  const badge = document.getElementById('ex-difficulty');
  badge.textContent = ex.difficulty;
  badge.className = `difficulty-badge diff-${ex.difficulty}`;
  
  // Título e enunciado
  document.getElementById('ex-title').textContent = `Ejercicio ${id}: ${ex.title}`;
  document.getElementById('ex-statement').textContent = ex.statement;
  document.getElementById('ex-pedagogical-hint').textContent = ex.pedagogicalHint;
  
  // Generar tarjetas de pasos
  const stepsContainer = document.getElementById('exercise-steps-container');
  stepsContainer.innerHTML = '';
  
  ex.steps.forEach((step, index) => {
    const card = document.createElement('div');
    card.className = `step-card ${index === 0 ? 'active' : ''}`;
    card.id = `step-card-${index}`;
    
    card.innerHTML = `
      <div class="step-num">${index + 1}</div>
      <div>
        <div class="step-title">${step.title}</div>
        <div class="step-desc">${step.desc}</div>
        <div class="step-math" style="margin-top: 8px; overflow-x: auto; display: none;">${step.math}</div>
      </div>
    `;
    stepsContainer.appendChild(card);
  });
  
  updateStepUI();
}

function updateStepUI() {
  const ex = exercisesDatabase[activeExId];
  const totalSteps = ex.steps.length;
  
  // Actualizar indicador textual
  document.getElementById('ex-step-indicator').textContent = `Paso ${activeStepIndex + 1} / ${totalSteps}`;
  
  // Controlar botones Prev/Next
  document.getElementById('btn-ex-prev').disabled = activeStepIndex === 0;
  
  const btnNext = document.getElementById('btn-ex-next');
  if (activeStepIndex === totalSteps - 1) {
    btnNext.innerHTML = 'Terminar <i class="fa-solid fa-circle-check"></i>';
    btnNext.className = 'btn btn-sm btn-secondary';
  } else {
    btnNext.innerHTML = 'Siguiente <i class="fa-solid fa-arrow-right"></i>';
    btnNext.className = 'btn btn-sm btn-primary';
  }
  
  // Modificar visibilidad de clases de pasos
  ex.steps.forEach((_, index) => {
    const card = document.getElementById(`step-card-${index}`);
    if (!card) return;
    
    const mathEl = card.querySelector('.step-math');
    
    if (index === activeStepIndex) {
      card.className = 'step-card active';
      if (mathEl) {
        mathEl.style.display = 'block';
        if (window.MathJax) {
          MathJax.typesetPromise([mathEl]);
        }
      }
    } else if (index < activeStepIndex) {
      card.className = 'step-card completed';
      if (mathEl) mathEl.style.display = 'block';
    } else {
      card.className = 'step-card';
      if (mathEl) mathEl.style.display = 'none';
    }
  });
  
  // Volver a dibujar el canvas del ejercicio
  triggerTabDraw('exercises');
}

/*=== 6. CONTROLADOR: 12 EJERCICIOS PROPUESTOS (PESTAÑA 7) ===*/
const proposedDatabase = {
  13: {
    title: "E13: Cálculo del Área de Sección Grande",
    difficulty: "basico",
    statement: "Determina el área de una corona circular de radio exterior \\(R = 15\\text{ cm}\\) e interior \\(r = 10\\text{ cm}\\).",
    solutionMath: "\\[A = 125\\pi \\approx 392.70\\text{ cm}^2\\]",
    explanation: "Aplicamos directamente la ecuación del área transversal sólida de una corona concéntrica: \\(A = \\pi(R^2 - r^2)\\). Sustituyendo valores: \\(A = \\pi(15^2 - 10^2) = \\pi(225 - 100) = 125\\pi \\approx 392.70\\text{ cm}^2\\)."
  },
  14: {
    title: "E14: Momento de Inercia de Componente Pesado",
    difficulty: "basico",
    statement: "Calcula el momento polar de inercia \\(J\\) para un volante con radio exterior \\(R = 25\\text{ cm}\\) y radio interior \\(r = 20\\text{ cm}\\).",
    solutionMath: "\\[J = 115,625\\pi \\approx 363,246.37\\text{ cm}^4\\]",
    explanation: "Sustituimos directamente los datos del enunciado en la fórmula principal del momento polar de inercia de cuarto orden: \\(J = \\frac{\\pi}{2}(R^4 - r^4)\\). Sustituyendo: \\(J = \\frac{\\pi}{2}(25^4 - 20^4) = \\frac{\\pi}{2}(390,625 - 160,000) = \\frac{\\pi}{2}(230,625) = 115,312.5\\pi \\approx 362,264.91\\text{ cm}^4\\)."
  },
  15: {
    title: "E15: Dimensión de Seguridad Cuadrada",
    difficulty: "basico",
    statement: "Un acoplamiento cuadrado posee un lado \\(L = 10\\text{ cm}\\). ¿Cuál es el radio exterior mínimo \\(R\\) que requiere un disco para contenerlo por completo sin que los vértices sobresalgan?",
    solutionMath: "\\[R \\ge 7.07\\text{ cm}\\]",
    explanation: "Para que un cuadrado esté totalmente inscrito, la distancia del centro a sus vértices debe ser el radio exterior \\(R\\). Por teorema de Pitágoras, la semidiagonal de un cuadrado de lado \\(L\\) es \\(d/2 = \\sqrt{(L/2)^2 + (L/2)^2} = \\frac{L}{\\sqrt{2}}\\). Así: \\(R \\ge \\frac{10}{\\sqrt{2}} \\approx 7.071\\text{ cm}\\)."
  },
  16: {
    title: "E16: Demostración Algebraica de Inercia por Área",
    difficulty: "basico",
    statement: "Demuestra algebraicamente la factorización del momento de inercia en función del área sólida: \\(J = \\frac{A}{2}(R^2 + r^2)\\).",
    solutionMath: "\\[\\text{Demostración completa mediante diferencia de cuadrados.}\\]",
    explanation: "Partimos de \\(J = \\frac{\\pi}{2}(R^4 - r^4)\\). Factorizamos la diferencia de cuadrados de cuarto orden: \\(R^4 - r^4 = (R^2 - r^2)(R^2 + r^2)\\). Sustituimos en \\(J\\): \\(J = \\frac{\\pi}{2}(R^2 - r^2)(R^2 + r^2) = \\frac{\\pi(R^2 - r^2)}{2}(R^2 + r^2)\\). Como el área es \\(A = \\pi(R^2 - r^2)\\), reemplazamos este factor y obtenemos: \\(J = \\frac{A}{2}(R^2 + r^2)\\)."
  },
  17: {
    title: "E17: Evaluación de Falla Estructural",
    difficulty: "intermedio",
    statement: "Un volante con \\(R = 20\\text{ cm}\\) y acople central cuadrado posee un agujero interior de \\(r = 15\\text{ cm}\\). Determina si el diseño sufrirá falla estructural.",
    solutionMath: "\\[\\text{Diseño Inseguro (Falla estructural)}\\]",
    explanation: "El límite seguro para un acople cuadrado inscrito es la apotema \\(a = R \\cos(45^\\circ) = 20 \\cdot 0.7071 = 14.14\\text{ cm}\\). Como el radio interior es \\(r = 15\\text{ cm}\\), y se cumple que \\(r > a\\) (\\(15 > 14.14\\)), el contorno del hueco central cortará los planos de soporte del cuadrado, destruyendo la integridad del acoplamiento."
  },
  18: {
    title: "E18: Rediseño a Acople Hexagonal",
    difficulty: "intermedio",
    statement: "Si el componente del problema anterior (\\(R=20\\text{ cm}\\), \\(r=15\\text{ cm}\\)) se rediseña utilizando una sujeción hexagonal regular (6 lados), ¿es seguro?",
    solutionMath: "\\[\\text{Diseño Seguro (Estable)}\\]",
    explanation: "Calculamos la apotema de un hexágono regular inscrito en un círculo de radio \\(R = 20\\text{ cm}\\): \\(a = R \\cos(30^\\circ) = 20 \\cdot 0.8660 = 17.32\\text{ cm}\\). Evaluando la condición de seguridad: \\(r = 15\\text{ cm}\\), como \\(r \\le a\\) (\\(15 \\le 17.32\\)), el hueco central queda dentro del límite de soporte plano del hexágono, haciendo que el diseño sea totalmente seguro."
  },
  19: {
    title: "E19: Perímetro de Disipación de Freno Óptimo",
    difficulty: "intermedio",
    statement: "Calcula el perímetro total de enfriamiento para un disco de embrague óptimo con radio exterior \\(R = 30\\text{ cm}\\) e interior \\(r = 21.21\\text{ cm}\\).",
    solutionMath: "\\[P \\approx 321.76\\text{ cm}\\]",
    explanation: "El perímetro total mojado es la suma del contorno interior y el exterior: \\(P = 2\\pi(R + r)\\). Reemplazamos: \\(P = 2\\pi(30 + 21.21) = 2\\pi(51.21) = 102.42\\pi \\approx 321.76\\text{ cm}\\)."
  },
  20: {
    title: "E20: Masa Física de Aro de Engranaje",
    difficulty: "intermedio",
    statement: "Un engranaje anular de bronce (densidad \\(\\rho = 8400\\text{ kg/m}^3\\)) de espesor \\(h = 2\\text{ cm}\\) posee radios \\(R = 12\\text{ cm}\\) y \\(r = 9\\text{ cm}\\). Calcula su masa total en kg.",
    solutionMath: "\\[M \\approx 3.325\\text{ kg}\\]",
    explanation: "El volumen es el área por el espesor: \\(A = \\pi(R^2 - r^2) = \\pi(12^2 - 9^2) = 63\\pi \\approx 197.92\\text{ cm}^2\\). Volumen: \\(V = A \\cdot h = 197.92 \\cdot 2 = 395.84\\text{ cm}^3 = 3.9584 \\times 10^{-4}\\text{ m}^3\\). La masa es \\(M = \\rho \\cdot V = 8400 \\cdot (3.9584 \\times 10^{-4}) \\approx 3.325\\text{ kg}\\)."
  },
  21: {
    title: "E21: Eficiencia Volumétrica de Corona Media",
    difficulty: "avanzado",
    statement: "Determina el porcentaje de ahorro de material y la inercia retenida para una corona circular con relación de radios \\(r/R = 0.5\\).",
    solutionMath: "\\[\\%\\text{Masa Ahorrada} = 25\\%, \\\\quad \\%\\text{Inercia Retenida} = 93.75\\%\\]",
    explanation: "Ahorro de masa = \\(\\frac{r^2}{R^2} = 0.5^2 = 0.25 = 25.0\\%\\). Inercia retenida = \\(1 - \\frac{r^4}{R^4} = 1 - 0.5^4 = 1 - 0.0625 = 93.75\\%\\). Este diseño es notable ya que elimina una cuarta parte del peso perdiendo menos del 7% de inercia."
  },
  22: {
    title: "E22: Rediseño y Espesor Compensatorio",
    difficulty: "avanzado",
    statement: "Un volante cilíndrico corona óptima (\\(r/R = 0.707\\)) debe igualar la inercia polar de un disco sólido de radio exterior \\(R\\). ¿En qué porcentaje debe incrementarse su espesor \\(h\\)?",
    solutionMath: "\\[\\Delta h = 33.33\\% \\\\text{ de incremento}\\]",
    explanation: "La inercia de la corona es \\(J_c = \\frac{\\pi}{2}(R^4 - r^4) h_c\\). Como \\(r^2 = 0.5 R^2 \\implies r^4 = 0.25 R^4\\), entonces \\(J_c = \\frac{\\pi}{2}(0.75 R^4) h_c = 0.75 J_s \\frac{h_c}{h_s}\\). Para que \\(J_c = J_s\\), se requiere que \\(0.75 \\frac{h_c}{h_s} = 1 \\implies h_c = 1.3333 h_s\\). Por tanto, el espesor debe aumentar un 33.33%."
  },
  23: {
    title: "E23: Apotema de Acoplamiento Triangular",
    difficulty: "avanzado",
    statement: "Halla la apotema \\(a\\) de un acoplamiento triangular equilátero (3 lados) inscrito en un círculo de radio exterior \\(R = 10\\text{ cm}\\).",
    solutionMath: "\\[a = 5.0\\text{ cm}\\]",
    explanation: "Para un triángulo equilátero regular inscrito, el número de lados es \\(n = 3\\). La fórmula de la apotema es \\(a = R \\cos(\\frac{180^\\circ}{3}) = R \\cos(60^\\circ)\\). Sustituyendo: \\(a = 10 \\cdot 0.5 = 5.0\\text{ cm}\\)."
  },
  24: {
    title: "E24: Deducción de Área Simétrica",
    difficulty: "avanzado",
    statement: "Deduce matemáticamente el valor límite exacto de la relación \\(r/R\\) para la cual la corona circular divide el área del círculo exterior en dos partes iguales.",
    solutionMath: "\\[r/R = \\frac{\\sqrt{2}}{2} \\approx 0.7071\\]",
    explanation: "Queremos que el área de la corona sea igual al área del hueco interior: \\(\\pi(R^2 - r^2) = \\pi r^2\\). Cancelando \\(\\pi\\) obtenemos: \\(R^2 - r^2 = r^2 \\implies R^2 = 2r^2\\). Dividiendo entre \\(R^2\\) y extrayendo la raíz: \\(\\frac{r^2}{R^2} = \\frac{1}{2} \\implies \\frac{r}{R} = \\sqrt{0.5} = \\frac{\\sqrt{2}}{2} \\approx 0.7071\\)."
  }
};

function initProposedExercises() {
  const container = document.getElementById('proposed-list-container');
  container.innerHTML = '';
  
  Object.keys(proposedDatabase).forEach(id => {
    const ex = proposedDatabase[id];
    
    const item = document.createElement('div');
    item.className = 'proposed-item';
    item.id = `proposed-${id}`;
    
    item.innerHTML = `
      <div class="proposed-header">
        <div class="proposed-title-container">
          <span class="difficulty-badge diff-${ex.difficulty}" style="margin-bottom:0;">${ex.difficulty}</span>
          <span class="proposed-title">${ex.title}</span>
        </div>
        <i class="fa-solid fa-chevron-down proposed-arrow"></i>
      </div>
      <div class="proposed-body">
        <div class="proposed-content">
          <div class="proposed-statement">${ex.statement}</div>
          <div class="proposed-solution-box">
            <div class="proposed-solution-title">
              <i class="fa-solid fa-square-root-variable"></i> Solución Detallada
            </div>
            <div class="proposed-solution-text">
              <div style="margin-bottom: 12px; overflow-x: auto;">${ex.solutionMath}</div>
              <p style="font-size: 0.85rem; color: var(--text-secondary); line-height:1.4;">${ex.explanation}</p>
            </div>
          </div>
        </div>
      </div>
    `;
    
    // Evento de Acordeón
    const header = item.querySelector('.proposed-header');
    const body = item.querySelector('.proposed-body');
    
    header.addEventListener('click', () => {
      const isExpanded = item.classList.contains('expanded');
      
      // Cerrar otros acordeones para mantener orden visual
      document.querySelectorAll('.proposed-item').forEach(otherItem => {
        if (otherItem !== item && otherItem.classList.contains('expanded')) {
          otherItem.classList.remove('expanded');
          otherItem.querySelector('.proposed-body').style.maxHeight = '0';
        }
      });
      
      if (isExpanded) {
        item.classList.remove('expanded');
        body.style.maxHeight = '0';
      } else {
        item.classList.add('expanded');
        body.style.maxHeight = body.scrollHeight + 100 + 'px'; // Altura dinámica
        
        // Disparar renderizado dinámico de MathJax
        if (window.MathJax) {
          MathJax.typesetPromise([body]).catch(err => console.log('MathJax accordion error:', err));
        }
      }
    });
    
    container.appendChild(item);
  });
}
